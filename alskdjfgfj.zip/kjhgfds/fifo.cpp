#include<bits/stdc++.h>
using namespace std;


void fifo(vector<int> & page,int win_size){
    queue<int> memory;
    unordered_map<int ,bool> present;
    int hit=0,miss=0;
    int i=0;
    while(i<page.size()){
        if(present.find(page[i])==present.end()|| present[page[i]]==false){
            memory.push(page[i]);
            present[page[i]]=true;
            miss++;
        }
        else{
            hit++;
        }
        while(memory.size()>win_size){
            int page_ref = memory.front();
            present[page_ref]=false;
            memory.pop();
        }
        i++;
    }

    cout<<hit<<" "<<miss;

}

int main(){
    int n ,win_size;
    cin>>n;
    cin>>win_size;
    vector<int> page(n);
    for(int i=0;i<n;i++){
        cin>>page[i];
    }
    fifo(page,win_size);
}