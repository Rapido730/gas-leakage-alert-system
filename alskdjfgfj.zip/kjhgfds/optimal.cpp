#include <bits/stdc++.h>
using namespace std;

int next_occur(vector<int> &pages,int ind){
    int index=100;
    for(int i=ind+1;i<pages.size();i++){
        if(pages[i]==pages[ind])
        {
            index=i;
            return index;
        }
    }
    return index;
}
// void show_queue(priority_queue<pair<int, int>> memory)
// {   
//     vector<pair<int,int>> v;
//     while(!memory.empty()){
//         v.push_back(memory.top());
//         cout << memory.top().first << " " << memory.top().second<<"    ";
//         memory.pop();
//     }
//     cout<<endl;
//     // for(auto it:v){
//     //     memory.push(it);
//     // }
// }
void optimal(vector<int> &pages, int win_size)
{
    priority_queue<pair<int,int>> memory;

    unordered_map<int, bool> present;
    int hit = 0, miss = 0;
    int i = 0;
    while (i < pages.size())
    {
        if (present.find(pages[i]) == present.end() || present[pages[i]] == false)
        {
            memory.push({next_occur(pages,i),pages[i]});
            present[pages[i]] = true;
            miss++;
            // cout<<pages[i]<<endl;
        }
        else
        {
            hit++;
        }
        while (memory.size() > win_size)
        {
            int page_ref = memory.top().second;
            cout<<page_ref<<endl;
            present[page_ref] = false;
            memory.pop();
        }
        i++; 

        // show_queue(memory);


    }

    cout << hit << " " << miss;
}

int main()
{
    int n, win_size;
    cin >> n;
    cin >> win_size;
    vector<int> pages(n);
    for (int i = 0; i < n; i++)
    {
        cin >> pages[i];
    }
    optimal(pages, win_size);
}