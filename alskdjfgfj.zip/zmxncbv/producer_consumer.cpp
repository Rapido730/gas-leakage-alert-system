#include<bits/stdc++.h>
#include <unistd.h>
#include <semaphore.h>


using namespace std;

pthread_t *producers;
pthread_t *consumers;

sem_t binary_s,empty_count,fill_count;

int *buf,buf_pos=-1,prod_count,con_count,buf_len;


int produce(pthread_t self){
	int i = 0;
	int p_item = 1 + rand()%50;
	while(!pthread_equal(*(producers+i),self) && i < prod_count){
		i++;
	}
	printf("Producer %d produced %d \n",i+1,p_item);
	return p_item;
}


void consume(int p,pthread_t self){
	int i = 0;
	while(!pthread_equal(*(consumers+i),self) && i < con_count){
		i++;
	}

	printf("Buffer:");
	for(int j=0;j<=buf_pos;++j)
		printf("%d ",*(buf+j));

	printf("\nConsumer %d consumed %d \nCurrent buffer len: %d\n",i+1,p,buf_pos);
	
}


void* producer(void *args){

	while(1){
		int p_item = produce(pthread_self());
		sem_wait(&empty_count);
		sem_wait(&binary_s);
		++buf_pos;			// critical section
		buf[buf_pos] = p_item; 
		sem_post(&binary_s);
		sem_post(&fill_count);
		sleep(1 + rand()%3);
	}
	
	return NULL;
}


void* consumer(void *args){
	int c;
	while(1){
		sem_wait(&fill_count);
		sem_wait(&binary_s);
		c = buf[buf_pos];
		consume(c,pthread_self());
		--buf_pos;
		sem_post(&binary_s);
		sem_post(&empty_count);
		sleep(1+rand()%5);
	}

	return NULL;
}

int main(void){
	
	int i,err;

	srand(time(NULL));

	sem_init(&binary_s,0,1);
	sem_init(&fill_count,0,0);

	cout<<"Enter the number of Producers:";
	cin>>prod_count;
	producers = new pthread_t[prod_count];

	cout<<"Enter the number of Consumers:";
	cin>>con_count;
	consumers = new pthread_t[con_count];

	printf("Enter buffer capacity:");
	scanf("%d",&buf_len);
	buf = (int*) malloc(buf_len*sizeof(int));

	sem_init(&empty_count,0,buf_len);

	for(i=0;i<prod_count;i++){
		err = pthread_create(producers+i,NULL,&producer,NULL);
		if(err != 0){
			printf("Error creating producer %d: %s\n",i+1,strerror(err));
		}else{
			printf("Successfully created producer %d\n",i+1);
		}
	}

	for(i=0;i<con_count;i++){
		err = pthread_create(consumers+i,NULL,&consumer,NULL);
		if(err != 0){
			printf("Error creating consumer %d: %s\n",i+1,strerror(err));
		}else{
			printf("Successfully created consumer %d\n",i+1);
		}
	}

	for(i=0;i<prod_count;i++){
		pthread_join(*(producers+i),NULL);
	}
	for(i=0;i<con_count;i++){
		pthread_join(*(consumers+i),NULL);
	}


	return 0;
}