
#include <bits/stdc++.h>
#include <semaphore.h>
#include <unistd.h>

using namespace std;

pthread_t *philosophers;
sem_t *s;

int phil_count, err;

int phil_index(pthread_t self)
{
    int i = 0;

    while (!pthread_equal(*(philosophers + i), self) && i < phil_count)
    {
        i++;
    }
    return i + 1;
}

void *philosopher_util(void *args)
{
    cout<<"hello"<<endl;
    int i = phil_index(pthread_self());
    while (true)
    {
        sem_wait(s+i);
        sem_wait(s+i+1);

        printf("Philosopher %d is eating \n", i);

        sem_post(s+i);
        sem_post(s+i+1);
        sleep(1 + rand() % 5);
    }

    return NULL;
}

int main()
{
    cout << "Enter number of Philosopher ";
    cin >> phil_count;

    philosophers = new pthread_t[phil_count];
    s = new sem_t[phil_count];

    for (int i = 0; i < phil_count; i++)
    {
        err = pthread_create(philosophers + i, NULL, &philosopher_util, NULL);
        if (err != 0)
        {
            printf("Error creating philosopher %d: %s\n", i + 1, strerror(err));
        }
        else
        {
            printf("Successfully created philosopher %d\n", i + 1);
        }
    }

    for (int i = 0; i < phil_count; i++)
    {
        pthread_join(*(philosophers + i), NULL);
    }

    return 0;
}