#include<bits/stdc++.h>
using namespace std;

class process{
    public:
    int pid;
    int bt;
    int at;
    int ct;
    int tat;
    int rem_bt;
    int wt;
    int priority;

    process(int v1,int v2,int v3, int v4){
        pid =v1;
        at = v2;
        bt = v3;
        rem_bt = v3;
        priority = v4;
    }
};

bool comparison(vector<int> a,vector<int> b){
	return a[3]<b[3];
}
struct compare{
    bool operator()(process* a,process* b){
    return a->priority!=b->rem_bt?a->priority<b->priority:(a->at>b->at);
}
};

int main(){

    vector<process*> pcb;
    int n ;
    cin>>n;
	int mini=INT_MAX;
    for(int i=0;i<n;i++){
        int pid;
        int at;
        int bt;
        int pri;
        cin>>pid>>at>>bt>>pri;
        pcb.push_back(new process(pid,at,bt,pri));
        mini = min(mini,at);
    }

    priority_queue<process*,vector<process*>,compare> pq;

    for(auto it:pcb){
        pq.push(it);
    }
    cout<<endl;
    int time=mini;
    vector<int> gantt_chart;

    while(!pq.empty()){
        vector<process*> temp;
        
        auto it = pq.top();
        pq.pop();

        while(!(it->at<=time)){
            temp.push_back(it);
            it = pq.top();
            pq.pop();
        }
        
        if(it->at<=time){
            it->rem_bt--;
            time++;
            gantt_chart.push_back(it->pid);

            if(it->rem_bt==0){
                int ct = time;
                int tat = ct - it->at;
                int wt = tat-it->bt;
                
                it->ct = ct;
                it->tat = tat;
                it->wt = wt;
            }
            else{
                pq.push(it);
            }
            
            if(temp.size()){
                for(auto t:temp)
                    pq.push(t);
            }
        }
        else {
            pq.push(it);
        }

    }


    for(auto it:pcb){
        
       cout<<it->pid<<" "<<it->at<<" "<<it->bt<<" "<<it->ct<<" "<<it->tat<<" "<<it->wt<<endl;
    }
    

    cout<<endl;
    for(int it:gantt_chart){
        
        
            cout<<"P"<<it<<" ";
        
        
    }

    return 0;
}
