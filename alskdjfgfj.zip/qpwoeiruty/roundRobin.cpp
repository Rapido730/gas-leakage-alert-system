#include<bits/stdc++.h>
using namespace std;

class process{
    public:
    int pid;
    int bt;
    int at;
    int ct;
    int tat;
    int rem_bt;
    int wt;
    int priority;

    process(int v1,int v2,int v3){
        pid =v1;
        at = v2;
        bt = v3;
        rem_bt=v3;
    }
};

struct compare
{
    bool operator()(process* a, process* b){
        return a->at>b->at;
    }
};


void RoundRobin(vector<process*> pcb, int &time,int time_slice){
    queue<process*> q;

    for(auto it:pcb){
        q.push(it);
    }

    cout<<endl;
    
    vector<int> gantt_chart;

     while(!q.empty()){
        
        auto it = q.front();
        q.pop();
        if(it->at<=time){
        
            int time_consumed = min(time_slice,it->rem_bt);
            it->rem_bt -= time_consumed;
            time += time_consumed;
            gantt_chart.push_back(it->pid);

            if(it->rem_bt==0){
                int ct = time;
                int tat = ct - it->at;
                int wt = tat-it->bt;
                
                it->ct = ct;
                it->tat = tat;
                it->wt = wt;
            }
            else{
                q.push(it);
            }
            
            
        }
        else {
            q.push(it);
        }

    }


    for(auto it:pcb){
        
       cout<<it->pid<<" "<<it->at<<" "<<it->bt<<" "<<it->ct<<" "<<it->tat<<" "<<it->wt<<endl;
    }
    

    cout<<endl;
    for(int it:gantt_chart){
        
        
            cout<<"P"<<it<<" ";
        
        
    }
}

int main(){

    vector<process*> pcb;
    int n ,time_slice;
    cin>>n>>time_slice;
	int mini=INT_MAX;

    for(int i=0;i<n;i++){
        int pid;
        int at;
        int bt;

        cin>>pid>>at>>bt;
        pcb.push_back(new process(pid,at,bt));
        mini = min(mini,at);
    }

    int time = mini;
    RoundRobin(pcb,time,time_slice);
    

    return 0;
}
