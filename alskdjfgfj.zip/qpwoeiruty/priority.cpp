#include<bits/stdc++.h>
using namespace std;

class process{
    public:
    int pid;
    int bt;
    int at;
    int ct;
    int tat;
    int rem_bt;
    int wt;
    int priority;

    process(int v1,int v2,int v3,int v4){
        pid =v1;
        at = v2;
        bt = v3;
        priority=v4;
    }
};

bool comparison(vector<int> a,vector<int> b){
	return a[3]<b[3];
}
struct compare{
    bool operator()(process* a,process* b){
    return a->priority<b->priority;
}
};

void priority(vector<process*> pcb, int &time){
    priority_queue<process*,vector<process*>,compare> pq;

    for(auto it:pcb){
        pq.push(it);
    }
    cout<<endl;
   
    vector<int> gantt_chart;

    while(!pq.empty()){
        vector<process*> temp;
        
        auto it = pq.top();
        pq.pop();

        while(!(it->at<=time)){
            temp.push_back(it);
            it = pq.top();
            pq.pop();
        }
        
        if(it->at<=time){
            int ct = time + it->bt;
            int tat = ct - it->at;
            int wt = tat-it->bt;
            time = ct;
            it->ct = ct;
            it->tat = tat;
            it->wt = wt;
            int t=it->bt;
            while(t--)
                gantt_chart.push_back(it->pid);
            if(temp.size()){
                for(auto t:temp)
                    pq.push(t);
            }
        }
        else {
            pq.push(it);
        }

    }


    for(auto it:pcb){
        
       cout<<it->pid<<" "<<it->at<<" "<<it->bt<<" "<<it->ct<<" "<<it->tat<<" "<<it->wt<<endl;
    }
    

    cout<<endl;
    for(int it:gantt_chart){
        
        
            cout<<"P"<<it<<" ";
        
        
    }
}

int main(){

    vector<process*> pcb;
    int n ;
    cin>>n;
	int mini=INT_MAX;
    for(int i=0;i<n;i++){
        int pid;
        int at;
        int bt;
        int pri;
        cin>>pid>>at>>bt>>pri;
        pcb.push_back(new process(pid,at,bt,pri));
        mini = min(mini,at);
    }
    int time=mini;
    priority(pcb,time);

    

    return 0;
}
