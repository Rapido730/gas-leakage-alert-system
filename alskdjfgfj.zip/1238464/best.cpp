#include <bits/stdc++.h>
using namespace std;

class process
{
public:
    int req_memory;
    int pid;
    int memory_allocated;
    int memory_index;

    process(int v1, int v2)
    {
        pid = v1;
        req_memory = v2;
    }
};

void best_fit(int nb, vector<int> &blocks, int np, vector<process *> &pcb)
{

    priority_queue<pair<int, int>> mem_blocks;

    for (int i = 0; i < nb; i++)
    {
        mem_blocks.push({-blocks[i], i+1});
    }

    // while(!mem_blocks.empty()){
    //     cout<<mem_blocks.top().first<<endl;
    //     mem_blocks.pop();
    // }

    for (int i = 0; i < np; i++)
    {
        vector<pair<int, int>> temp;

        while (!mem_blocks.empty())
        {
            int memory_size = -mem_blocks.top().first;
            int index = mem_blocks.top().second;
            mem_blocks.pop();

            if (memory_size >= pcb[i]->req_memory)
            {
                pcb[i]->memory_allocated = memory_size;
                pcb[i]->memory_index = index;
                break;
            }
            else
            {
                temp.push_back({-memory_size, index});
            }
        }
        cout << endl;

        for (auto it : temp)
        {
            mem_blocks.push({it.first, it.second});
        }
    }

    for (int i = 0; i < np; i++)
    {
        cout << pcb[i]->pid << " " << pcb[i]->req_memory << " " << pcb[i]->memory_index << " " << pcb[i]->memory_allocated << endl;
    }
}

int main()
{
    int nb, np;
    cin >> nb >> np;
    vector<int> blocks(nb);
    vector<process *> pcb;

    for (int i = 0; i < nb; i++)
    {
        cin >> blocks[i];
    }

    for (int i = 0; i < np; i++)
    {
        int memory;
        cin >> memory;
        pcb.push_back(new process(i + 1, memory));
    }

    best_fit(nb, blocks, np, pcb);
}