#include <bits/stdc++.h>
using namespace std;

vector<int> getKey()
{
    unordered_map<int, bool> mp;
    vector<int> key(26);

    for (int i = 0; i < 26; i++)
    {
        int ind = rand() % 26;

        while (mp.find(ind) != mp.end())
        {
            ind = rand() % 26;
        }
        mp[ind] = true;
        key[ind] = i;
    }

    return key;
}

// vector<vector<int>> ans;

void nextPermutation(vector<int> &nums)
{

    int n = nums.size();
    int i, k;

    for (i = n - 2; i >= 0; i--)
    {
        if (nums[i] < nums[i + 1])
        {
            break; // to find break point
        }
    }

    // then find just greater element than nums[i] from back

    if (i < 0)
    {
        sort(nums.begin(), nums.end()); // its last permutation
    }
    else
    {
        for (k = n - 1; k > i; k--)
        {
            if (nums[k] > nums[i])
            {
                break;
            }
        }

        swap(nums[k], nums[i]); // swap element

        reverse(nums.begin() + i + 1, nums.end()); // reverse the left array to make jsut next permutaion.
    }
}

string encrypt(string s, vector<int> &key)
{
    string ciphertext = "";
    for (int i = 0; i < s.length(); i++)
    {
        if (s[i] != ' ')
            ciphertext.push_back(char(key[s[i] - 'a'] + 'a'));
    }

    return ciphertext;
}

vector<int> complement(vector<int> &key)
{
    vector<int> resultKey(26);

    for (int i = 0; i < 26; i++)
    {
        resultKey[key[i]] = i;
    }
    return resultKey;
}

string decrypt(string s, vector<int> &key)
{
    vector<int> reverseKey = complement(key);

    return encrypt(s, reverseKey);
}

void cryptananlysis(vector<int> &key, string ciphertext)
{

    while (true)
    {

        string plaintext = decrypt(ciphertext, key);
        int decision;
        cout << "\n\ndecrypted plaintext = " << plaintext << endl;
        cout << "if it is correct then press 1 otherwise 0\n";
        cin >> decision;
        if (decision == 1)
        {
            cout << "hurray attack succeful\n";
            return;
        }

        cout << "try again \n";
        nextPermutation(key);
    }
}
int main()
{
    srand(time(0));
    vector<int> key = getKey();
    string ciphertext;

    cout << "ciphertex = ";
    cin >> ciphertext;
    cryptananlysis(key, ciphertext);
}

// sdfghjkcnsdkcjd