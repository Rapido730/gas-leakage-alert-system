#ifndef AES_Encryption_HPP
#define AES_Encryption_HPP

#include <bits/stdc++.h>

using namespace std;

string xor_op(string a, string b)
{
    string ans = "";
    for (long long i = 0; i < a.size(); i++)
    {
        if (a[i] == b[i])
        {
            ans.push_back('0');
        }
        else
        {
            ans.push_back('1');
        }
    }

    return ans;
}

long long binaryToInteger(string s)
{
    long long exp = 1;
    long long res = 0;
    for (long long i = s.length() - 1; i >= 0; i--)
    {
        res += (exp * (s[i] - '0'));
        exp *= 2;
    }

    return res;
}

string integerToBinary(long long num)
{
    string ans;

    long long temp = num % 2;

    while (num)
    {
        ans.push_back('0' + num % 2);
        num = num / 2;
    }

    while (ans.size() < 4)
    {
        ans.push_back('0');
    }

    reverse(ans.begin(), ans.end());

    return ans;
}
string HexaToBin(string hexa)
{
    string ans = "";

    for (char c : hexa)
    {

        if (c <= '9')
            ans += integerToBinary(c - '0');
        else
        {
            ans += integerToBinary(c - 'a' + 10);
        }
    }

    return ans;
}
char IntToHexa(long long temp)
{

    if (temp < 10)
    {
        return ('0' + temp);
    }
    return ('a' + temp - 10);
}
string BinToHexa(string msg)
{

    string hexa = "";
    int n = msg.length() - 1;
    while (n)
    {

        long long temp = 0;
        long long exp = 1;
        int len = n;

        for (long long i = len; i > max(len - 4, 0); i--)
        {

            temp += (msg[i] - '0') * exp;
            exp *= 2;
        }

        hexa.push_back(IntToHexa(temp));
        n = max(n - 4, 0);
    }

    reverse(hexa.begin(), hexa.end());

    return hexa;
}
void applyMod2(vector<long long> &a)
{
    long long n = a.size();
    for (long long i = 0; i < n; i++)
    {
        if (a[i] < 0)
            a[i] = (-a[i]);
        a[i] %= 2;
    }
    while (a.size() > 0 && a.back() == 0)
        a.pop_back();
}
vector<long long> Sub_Pol(vector<long long> poly1, vector<long long> poly2)
{
    long long len = max(poly1.size(), poly2.size());
    vector<long long> res;
    for (long long ind = 0; ind < len; ind++)
    {
        if (ind < poly1.size() && ind < poly2.size())
        {
            res.push_back(poly1[ind] - poly2[ind]);
        }
        else if (ind < poly1.size())
        {
            res.push_back(poly1[ind]);
        }
        else
        {
            res.push_back(poly2[ind]);
        }
    }
    return res;
}
vector<long long> Mul_Pol(vector<long long> poly1, vector<long long> poly2)
{
    long long len1 = poly1.size(), len2 = poly2.size();

    vector<long long> res(len1 + len2 - 1);
    for (long long i = 0; i < len1; i++)
    {
        for (long long j = 0; j < len2; j++)
        {
            res[i + j] += poly1[i] * poly2[j];
        }
    }
    return res;
}

vector<vector<long long>> Div_Pol(vector<long long> a, vector<long long> b)
{
    long long n = b.size();
    vector<long long> q = vector<long long>(a.size() - n + 1);
    while (a.size() >= n)
    {
        long long coef = a.back() / b.back();
        long long deg = a.size() - b.size();
        q[deg] = coef;
        q[deg] %= 2;
        for (long long i = 0; i < n; i++)
        {
            a[a.size() - 1 - i] -= coef * b[b.size() - 1 - i];
        }
        while (a.size() > 0 && a.back() == 0)
            a.pop_back();
    }
    return {q, a};
}

vector<long long> GetInv(vector<long long> a, vector<long long> b, vector<long long> t1, vector<long long> t2)
{
    if (b.size() == 0)
    {
        return t1;
    }
    if (b.size() == 1 && b[0] == 0)
    {
        return t1;
    }
    vector<long long> q, r;
    vector<vector<long long>> tmp = Div_Pol(a, b);

    q = tmp[0], r = tmp[1];
    applyMod2(q);
    applyMod2(r);
    vector<long long> t;
    vector<long long> tmpMul = Mul_Pol(q, t2);
    applyMod2(tmpMul);
    t = Sub_Pol(t1, tmpMul);
    applyMod2(t);
    return GetInv(b, r, t2, t);
}
char Int_To_Hexa(long long val)
{
    if (val >= 0 && val <= 9)
        return (val + '0');
    if (val == 10)
        return 'a';
    else if (val == 11)
        return 'b';
    else if (val == 12)
        return 'c';
    else if (val == 13)
        return 'd';
    else if (val == 14)
        return 'e';
    else
        return 'f';
}
long long Hexa_To_Int(char a)
{
    long long val = 0;
    if (isdigit(a))
        val = a - '0';
    else
    {
        if (a == 'a')
            val = 10;
        else if (a == 'b')
            val = 11;
        else if (a == 'c')
            val = 12;
        else if (a == 'd')
            val = 13;
        else if (a == 'e')
            val = 14;
        else
            val = 15;
    }
    return val;
}
vector<long long> Hex_To_Binary(char a)
{
    long long val = 0;
    if (isdigit(a))
        val = a - '0';
    else
    {
        if (a == 'a')
            val = 10;
        else if (a == 'b')
            val = 11;
        else if (a == 'c')
            val = 12;
        else if (a == 'd')
            val = 13;
        else if (a == 'e')
            val = 14;
        else
            val = 15;
    }
    vector<long long> res(4, 0);
    if (val > 15)
        return res;
    long long ind = 3;
    while (val > 0)
    {

        res[ind] = val % 2;
        val = val / 2;
        ind--;
    }

    return res;
}
vector<long long> changepoly(vector<long long> &a)
{
    while (a.size() > 0 && a.back() == 0)
    {
        a.pop_back();
    }
    if (a.size() == 0)
        a.push_back(0);
    return a;
}
vector<vector<string>> sboxCreation(vector<vector<string>> s)
{
    vector<vector<long long>> matrix = {
        {1, 0, 0, 0, 1, 1, 1, 1},
        {1, 1, 0, 0, 0, 1, 1, 1},
        {1, 1, 1, 0, 0, 0, 1, 1},
        {1, 1, 1, 1, 0, 0, 0, 1},
        {1, 1, 1, 1, 1, 0, 0, 0},
        {0, 1, 1, 1, 1, 1, 0, 0},
        {0, 0, 1, 1, 1, 1, 1, 0},
        {0, 0, 0, 1, 1, 1, 1, 1}};

    vector<vector<string>> sdash(4, vector<string>(4, ""));
    vector<long long> y = {1, 1, 0, 0, 0, 1, 1, 0};

    for (long long row = 0; row < 4; row++)
    {
        for (long long col = 0; col < 4; col++)
        {
            string cur = s[row][col];

            vector<long long> firstHalf = Hex_To_Binary(cur[0]), secondHalf = Hex_To_Binary(cur[1]);
            vector<long long> b;
            for (auto it : firstHalf)
            {
                b.push_back(it);
            }
            for (auto it : secondHalf)
            {

                b.push_back(it);
            }
            reverse(b.begin(), b.end());
            b = changepoly(b);

            vector<long long> c = {1, 1, 0, 1, 1, 0, 0, 0, 1};
            vector<long long> t1 = {0}, t2 = {1};
            vector<long long> mi = GetInv(c, b, t1, t2);

            while (mi.size() < 8)
            {
                mi.push_back(0);
            }

            vector<long long> multires;

            for (long long i = 0; i < 8; i++)
            {
                long long value = 0;
                for (long long j = 0; j < 8; j++)
                {
                    value += matrix[i][j] * mi[j];
                }
                value %= 2;
                multires.push_back(value);
            }

            vector<long long> bdash;

            for (long long i = 0; i < 8; i++)
            {
                bdash.push_back(multires[i] ^ y[i]);
            }

            reverse(bdash.begin(), bdash.end());
            long long f1 = 0, f2 = 0;
            long long k = 1;
            for (long long i = 3; i >= 0; i--)
            {
                f1 = f1 + bdash[i] * k;
                k *= 2;
            }
            k = 1;
            for (long long i = 7; i >= 4; i--)
            {
                f2 = f2 + bdash[i] * k;
                k *= 2;
            }
            string subWord = "";
            subWord += Int_To_Hexa(f1);
            subWord += Int_To_Hexa(f2);
            sdash[row][col] = subWord;
        }
    }
    return sdash;
}
void shiftRows(vector<vector<string>> &box)
{
    rotate(box[1].begin(), box[1].begin() + 1, box[1].end());
    rotate(box[2].begin(), box[2].begin() + 2, box[2].end());
    rotate(box[3].begin(), box[3].begin() + 3, box[3].end());
}
vector<string> doXor(vector<string> a, vector<string> b)
{

    vector<string> res;
    for (long long i = 0; i < 4; i++)
    {
        string tmp1 = a[i], tmp2 = b[i];
        long long get_1 = Hexa_To_Int(tmp1[0]) ^ Hexa_To_Int(tmp2[0]);
        long long get_2 = Hexa_To_Int(tmp1[1]) ^ Hexa_To_Int(tmp2[1]);
        string ans = "";
        ans += Int_To_Hexa(get_1);
        ans += Int_To_Hexa(get_2);
        res.push_back(ans);
    }
    return res;
}
void generateSBox(vector<vector<string>> &sbox)
{

    vector<vector<long long>> matrix = {
        {1, 0, 0, 0, 1, 1, 1, 1},
        {1, 1, 0, 0, 0, 1, 1, 1},
        {1, 1, 1, 0, 0, 0, 1, 1},
        {1, 1, 1, 1, 0, 0, 0, 1},
        {1, 1, 1, 1, 1, 0, 0, 0},
        {0, 1, 1, 1, 1, 1, 0, 0},
        {0, 0, 1, 1, 1, 1, 1, 0},
        {0, 0, 0, 1, 1, 1, 1, 1}};

    vector<long long> y = {1, 1, 0, 0, 0, 1, 1, 0};
    for (long long row = 0; row < 16; row++)
    {
        for (long long col = 0; col < 16; col++)
        {
            char fs = Int_To_Hexa(row), ss = Int_To_Hexa(col);

            vector<long long> firstHalf = Hex_To_Binary(fs), secondHalf = Hex_To_Binary(ss);
            vector<long long> b;
            for (auto it : firstHalf)
            {
                b.push_back(it);
            }
            for (auto it : secondHalf)
            {

                b.push_back(it);
            }
            reverse(b.begin(), b.end());
            b = changepoly(b);

            vector<long long> c = {1, 1, 0, 1, 1, 0, 0, 0, 1};
            vector<long long> t1 = {0}, t2 = {1};
            vector<long long> mi = GetInv(c, b, t1, t2);

            while (mi.size() < 8)
            {
                mi.push_back(0);
            }

            vector<long long> multires;

            for (long long i = 0; i < 8; i++)
            {
                long long value = 0;
                for (long long j = 0; j < 8; j++)
                {
                    value += matrix[i][j] * mi[j];
                }
                value %= 2;
                multires.push_back(value);
            }

            vector<long long> bdash;

            for (long long i = 0; i < 8; i++)
            {
                bdash.push_back(multires[i] ^ y[i]);
            }
            reverse(bdash.begin(), bdash.end());
            long long f1 = 0, f2 = 0;
            long long k = 1;
            for (long long i = 3; i >= 0; i--)
            {
                f1 = f1 + bdash[i] * k;
                k *= 2;
            }
            k = 1;
            for (long long i = 7; i >= 4; i--)
            {
                f2 = f2 + bdash[i] * k;
                k *= 2;
            }
            string subWord = "";
            subWord += Int_To_Hexa(f1);
            subWord += Int_To_Hexa(f2);
            sbox[row][col] = subWord;
        }
    }
}

void substutiteInSbox(vector<string> &s)
{
    vector<vector<long long>> matrix = {
        {1, 0, 0, 0, 1, 1, 1, 1},
        {1, 1, 0, 0, 0, 1, 1, 1},
        {1, 1, 1, 0, 0, 0, 1, 1},
        {1, 1, 1, 1, 0, 0, 0, 1},
        {1, 1, 1, 1, 1, 0, 0, 0},
        {0, 1, 1, 1, 1, 1, 0, 0},
        {0, 0, 1, 1, 1, 1, 1, 0},
        {0, 0, 0, 1, 1, 1, 1, 1}};
    vector<long long> y = {1, 1, 0, 0, 0, 1, 1, 0};
    vector<char> words[4];
    for (long long i = 0; i < 4; i++)
    {
        words[i].push_back(s[i][0]);
        words[i].push_back(s[i][1]);
    }
    long long ind = 0;
    for (long long i = 0; i < 8; i += 2)
    {
        vector<long long> firstHalf = Hex_To_Binary(words[ind][0]), secondHalf = Hex_To_Binary(words[ind + 1][1]);
        vector<long long> b;
        for (auto it : firstHalf)
        {
            b.push_back(it);
        }
        for (auto it : secondHalf)
        {
            b.push_back(it);
        }
        reverse(b.begin(), b.end());
        b = changepoly(b);
        vector<long long> c = {1, 1, 0, 1, 1, 0, 0, 0, 1};
        vector<long long> t1 = {0}, t2 = {1};
        vector<long long> mi = GetInv(c, b, t1, t2);
        while (mi.size() < 8)
        {
            mi.push_back(0);
        }
        vector<long long> multires;
        for (long long i = 0; i < 8; i++)
        {
            long long value = 0;
            for (long long j = 0; j < 8; j++)
            {
                value += matrix[i][j] * mi[j];
            }
            value %= 2;
            multires.push_back(value);
        }
        vector<long long> bdash;
        for (long long i = 0; i < 8; i++)
        {
            bdash.push_back(multires[i] ^ y[i]);
        }
        reverse(bdash.begin(), bdash.end());
        long long f1 = 0, f2 = 0;
        long long k = 1;
        for (long long i = 3; i >= 0; i--)
        {
            f1 = f1 + bdash[i] * k;
            k *= 2;
        }
        k = 1;
        for (long long i = 7; i >= 4; i--)
        {
            f2 = f2 + bdash[i] * k;
            k *= 2;
        }
        string subWord = "";
        subWord += Int_To_Hexa(f1);
        subWord += Int_To_Hexa(f2);
        s[ind] = subWord;
        ind++;
    }
}
void substitueSbox(vector<vector<string>> sbox, vector<vector<string>> &state)
{
    for (long long row = 0; row < 4; row++)
    {
        for (long long col = 0; col < 4; col++)
        {
            string tmp = state[row][col];
            long long currow = Hexa_To_Int(tmp[0]), curcol = Hexa_To_Int(tmp[1]);
            state[row][col] = sbox[currow][curcol];
        }
    }
}
void subWord(vector<string> &word, vector<vector<string>> sbox)
{
    for (long long i = 0; i < 4; i++)
    {
        char a = word[i][0], b = word[i][1];
        long long row = Hexa_To_Int(a), col = Hexa_To_Int(b);
        string tmpSub = sbox[row][col];
        word[i] = tmpSub;
    }
}
void printVector(vector<string> a)
{
    cout << endl;
    for (auto it : a)
        cout << it << " ";
    cout << endl;
}
vector<vector<string>> keyExpansion(vector<vector<string>> key, vector<vector<string>> sbox)
{
    vector<vector<string>> w(44);
    map<long long, vector<char>> rc;
    rc.insert({1, {'0', '1', '0', '0', '0', '0', '0', '0'}});
    rc.insert({2, {'0', '2', '0', '0', '0', '0', '0', '0'}});
    rc.insert({3, {'0', '4', '0', '0', '0', '0', '0', '0'}});
    rc.insert({4, {'0', '8', '0', '0', '0', '0', '0', '0'}});
    rc.insert({5, {'1', '0', '0', '0', '0', '0', '0', '0'}});
    rc.insert({6, {'2', '0', '0', '0', '0', '0', '0', '0'}});
    rc.insert({7, {'4', '0', '0', '0', '0', '0', '0', '0'}});
    rc.insert({8, {'8', '0', '0', '0', '0', '0', '0', '0'}});
    rc.insert({9, {'1', 'b', '0', '0', '0', '0', '0', '0'}});
    rc.insert({10, {'3', '6', '0', '0', '0', '0', '0', '0'}});
    w[0] = key[0];
    w[1] = key[1];
    w[2] = key[2];
    w[3] = key[3];

    vector<vector<string>> Round_Keys;
    Round_Keys.push_back(w[0]);
    Round_Keys.push_back(w[1]);
    Round_Keys.push_back(w[2]);
    Round_Keys.push_back(w[3]);
    for (long long i = 4; i < 44; i++)
    {
        if (i % 4 == 0)
        {
            vector<string> wordi_1 = w[i - 1];
            string curWord = wordi_1[0];
            rotate(wordi_1.begin(), wordi_1.begin() + 1, wordi_1.end());
            subWord(wordi_1, sbox);

            long long rnd = i / 4;
            vector<char> rc_round = rc[rnd];
            vector<string> rcDash;
            for (long long k = 0; k < 8; k += 2)
            {
                string curWord = "";
                curWord += rc_round[k];
                curWord += rc_round[k + 1];
                rcDash.push_back(curWord);
            }
            vector<string> t = doXor(wordi_1, rcDash);
            w[i] = doXor(t, w[i - 4]);
        }
        else
        {
            w[i] = doXor(w[i - 1], w[i - 4]);
        }
        Round_Keys.push_back(w[i]);
    }
    return Round_Keys;
}
vector<long long> addPolynomial(vector<long long> a, vector<long long> b)
{
    vector<long long> res;
    while (a.size() < 8)
        a.push_back(0);
    while (b.size() < 8)
        b.push_back(0);
    for (long long i = 0; i < 8; i++)
    {
        long long val = (a[i] + b[i]) % 2;
        res.push_back(val);
    }
    return res;
}
string multiMatrix(string a, string b)
{
    vector<long long> tmp1_0 = Hex_To_Binary(a[0]), tmp1_1 = Hex_To_Binary(a[1]);
    vector<long long> tmp2_0 = Hex_To_Binary(b[0]), tmp2_1 = Hex_To_Binary(b[1]);
    vector<long long> aPoly, bPoly;
    for (auto it : tmp1_0)
        aPoly.push_back(it);
    for (auto it : tmp1_1)
        aPoly.push_back(it);
    for (auto it : tmp2_0)
        bPoly.push_back(it);
    for (auto it : tmp2_1)
        bPoly.push_back(it);
    reverse(aPoly.begin(), aPoly.end());
    reverse(bPoly.begin(), bPoly.end());
    applyMod2(aPoly);
    if (aPoly.size() == 0)
        aPoly.push_back(0);
    applyMod2(bPoly);
    if (bPoly.size() == 0)
        bPoly.push_back(0);
    vector<long long> tmpk = {1, 1, 0, 1, 1, 0, 0, 0, 1};
    vector<long long> ans = Mul_Pol(aPoly, bPoly);
    applyMod2(ans);
    if (ans.size() > 8)
    {
        vector<vector<long long>> zk = Div_Pol(ans, tmpk);
        ans = zk[1];
    }
    applyMod2(ans);
    if (ans.size() == 0)
        return "00";
    while (ans.size() < 8)
        ans.push_back(0);
    long long val1 = 0, k = 1;
    for (long long i = 0; i < 4; i++)
    {
        val1 += ans[i] * k;
        k *= 2;
    }
    long long val2 = 0;
    k = 1;
    for (long long i = 4; i < 8; i++)
    {
        val2 += ans[i] * k;
        k *= 2;
    }
    string res = "";
    res += Int_To_Hexa(val2);
    res += Int_To_Hexa(val1);
    return res;
}
string addMatrix(string a, string b)
{
    if (a == "00")
        return b;
    if (b == "00")
        return a;
    vector<long long> tmp1_0 = Hex_To_Binary(a[0]), tmp1_1 = Hex_To_Binary(a[1]);
    vector<long long> tmp2_0 = Hex_To_Binary(b[0]), tmp2_1 = Hex_To_Binary(b[1]);
    vector<long long> aPoly, bPoly;
    for (auto it : tmp1_0)
        aPoly.push_back(it);
    for (auto it : tmp1_1)
        aPoly.push_back(it);
    for (auto it : tmp2_0)
        bPoly.push_back(it);
    for (auto it : tmp2_1)
        bPoly.push_back(it);
    reverse(aPoly.begin(), aPoly.end());
    reverse(bPoly.begin(), bPoly.end());
    applyMod2(aPoly);
    if (aPoly.size() == 0)
        aPoly.push_back(0);
    applyMod2(bPoly);
    if (bPoly.size() == 0)
        bPoly.push_back(0);
    vector<long long> ans = addPolynomial(aPoly, bPoly);
    if (ans.size() == 0)
        return "00";
    while (ans.size() < 8)
        ans.push_back(0);
    long long val1 = 0, k = 1;
    for (long long i = 0; i < 4; i++)
    {
        val1 += ans[i] * k;
        k *= 2;
    }
    long long val2 = 0;
    k = 1;
    for (long long i = 4; i < 8; i++)
    {
        val2 += ans[i] * k;
        k *= 2;
    }
    string res = "";
    res += Int_To_Hexa(val2);
    res += Int_To_Hexa(val1);
    return res;
}
vector<vector<string>> mixColumns(vector<vector<string>> state)
{
    vector<vector<string>> constantMatrix = {
        {"02", "03", "01", "01"},
        {"01", "02", "03", "01"},
        {"01", "01", "02", "03"},
        {"03", "01", "01", "02"}};
    vector<vector<string>> res(4, vector<string>(4, "00"));
    for (long long i = 0; i < 4; i++)
    {
        for (long long j = 0; j < 4; j++)
        {
            for (long long k = 0; k < 4; k++)
            {
                vector<long long> tmpk = {1, 1, 0, 1, 0, 0, 0, 1};
                string multitemp = multiMatrix(constantMatrix[i][k], state[k][j]);
                res[i][j] = addMatrix(multitemp, res[i][j]);
            }
        }
    }
    return res;
}
vector<vector<string>> MatrixXor(vector<vector<string>> a, vector<vector<string>> b)
{
    vector<vector<string>> res;
    for (long long i = 0; i < 4; i++)
    {
        vector<string> tmp = doXor(a[i], b[i]);
        res.push_back(tmp);
    }
    return res;
}
vector<vector<string>> getRoundKey(vector<vector<string>> Round_Keys, long long ind)
{
    vector<vector<string>> tmpKeys;
    vector<vector<string>> res(4, vector<string>(4, ""));
    tmpKeys.push_back(Round_Keys[ind]);
    tmpKeys.push_back(Round_Keys[ind + 1]);
    tmpKeys.push_back(Round_Keys[ind + 2]);
    tmpKeys.push_back(Round_Keys[ind + 3]);
    for (long long row = 0; row < 4; row++)
    {
        for (long long col = 0; col < 4; col++)
        {
            res[col][row] = tmpKeys[row][col];
        }
    }
    return res;
}
void printMatrix(vector<vector<string>> a)
{
    cout << endl;
    for (long long row = 0; row < 4; row++)
    {
        for (long long col = 0; col < 4; col++)
        {
            cout << a[row][col] << " ";
        }
        cout << endl;
    }
    cout << endl;
}

void get_word_Mat(string s, vector<vector<string>> &words, vector<vector<string>> &key, string k)
{
    long long ind = 0;
    for (long long i = 0; i < 4; i++)
    {
        for (long long j = 0; j < 4; j++)
        {
            string tmp = "";
            string tmpWord = "";
            tmpWord += s[ind];
            tmpWord += s[ind + 1];
            words[j][i] = tmpWord;
            tmp += k[ind];
            tmp += k[ind + 1];
            key[i][j] = tmp;
            ind += 2;
        }
    }
}

string aes(vector<vector<string>> sbox, vector<vector<string>> word, vector<vector<string>> Round_Keys)
{
    long long round = 0;
    long long windex = 0;
    vector<vector<string>> curKey = getRoundKey(Round_Keys, windex);
    windex += 4;
    long long ri = 1;
    vector<vector<string>> statecur = MatrixXor(word, curKey);
    for (long long rnd = 0; rnd < 9; rnd++)
    {
        substitueSbox(sbox, statecur);
        shiftRows(statecur);
        statecur = mixColumns(statecur);
        curKey = getRoundKey(Round_Keys, windex);
        windex += 4;
        ri++;
        statecur = MatrixXor(statecur, curKey);
    }

    substitueSbox(sbox, statecur);
    shiftRows(statecur);
    curKey = getRoundKey(Round_Keys, windex);
    statecur = MatrixXor(statecur, curKey);
    string ciphertext = "";
    for (auto it : statecur)
    {
        for (string i : it)
        {
            ciphertext += i;
        }
    }
    return ciphertext;
}

string AES_Encryption(string s, string k)
{
    s = BinToHexa(s);
    k = BinToHexa(k);
    vector<vector<string>> sbox(16, vector<string>(16, ""));
    generateSBox(sbox);
    vector<vector<string>> words(4, vector<string>(4, ""));
    vector<vector<string>> key(4, vector<string>(4, ""));
    get_word_Mat(s, words, key, k);
    vector<vector<string>> Round_Keys = keyExpansion(key, sbox);
    return HexaToBin(aes(sbox, words, Round_Keys));
}
string getHexaMsg()
{

    long long n = rand() % 1000 + 500;
    string s = "";

    while (n--)
    {
        long long temp = rand() % 16;

        if (temp < 10)
        {
            s.push_back('0' + temp);
        }
        else
        {
            s.push_back('a' + temp - 10);
        }
    }
    return s;
}

string InitialVector()
{
    long long n = 128;
    string s = "";

    while (n--)
    {
        long long temp = rand() % 2;

        s.push_back('0' + temp);
    }
    return s;
}

string getBinMsg()
{

    long long n = rand() % 500 + 200;
    string s = "";

    while (n--)
    {
        long long temp = rand() % 2;

        s.push_back('0' + temp);
    }
    return s;
}

string padding(string msg)
{

    long long len = msg.length();

    len = len % 128;
    if (len != 0)
    {
        len = 128 - len;
        msg = msg + "1";
        len--;
        while (len--)
        {
            msg += "0";
        }
    }
    return msg;
}

string compression(string H, string msg_block)
{
    string ciphertext = AES_Encryption(msg_block, H);
    string H_next = xor_op(ciphertext, H);
    return H_next;
}

string hashing(string msg)
{
    long long block_size = 128;
    long long round = msg.size() / block_size;
    long long i = 0;
    string m = msg.substr(0, block_size);
    string iv = "00110100110110110110110101100011111010000101101011011000011111111111101111101011101101010100110110101010110100110001010011111100";
    cout << "\ninitial vector = " << iv << endl;
    string H = iv;
    while (i < round)
    {
        string msg_block = msg.substr(i * 128, 128);
        string H_next = compression(H, msg_block);
        H = H_next;
        i++;
    }

    return H;
}

string hash_function(string msg)
{

    string msg1 = padding(msg);
    // cout << "\nafter padding = " << msg1 << endl;
    string Message_digest = hashing(msg1);
    // cout
    // << "\nMessage disgest = " << Message_disgest << endl;

    return Message_digest;
    // cout<<mod_pow(5,-1,7);
}

#endif