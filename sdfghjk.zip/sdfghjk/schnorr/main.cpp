#include <bits/stdc++.h>
#include "aes_encryption.hpp"
using namespace std;

int gcd_extended(int a, int b, int &X, int &Y)
{
    if (a == 0)
    {
        X = 0;
        Y = 1;
        return b;
    }
    int X1, Y1;
    int gcd = gcd_extended(b % a, a, X1, Y1);

    X = Y1 - X1 * (b / a);
    Y = X1;

    return gcd;
}

int getInv(int num, int mod)
{

    int X;
    int Y;

    gcd_extended(num, mod, X, Y);

    while (X < 0)
    {
        X = (X + mod) % mod;
    }
    return X;
}

int mod_mul(int a, int b, int mod)
{

    return ((a % mod) * (b % mod)) % mod;
}

int mod_pow(int x, int y, int mod)
{

    if (y == 0)
    {
        return 1;
    }
    int flag = 0;
    int neg = false;

    if (y < 0)
    {
        neg = true;
        y = abs(y);
    }

    int ans = mod_pow(x, y / 2, mod);

    if (y % 2)
    {
        if (neg)
        {

            return getInv(mod_mul(mod_mul(ans, ans, mod), x, mod), mod);
        }
        else
        {
            return mod_mul(mod_mul(ans, ans, mod), x, mod);
        }
    }

    if (neg)
        return getInv(mod_mul(ans, ans, mod), mod);

    return mod_mul(ans, ans, mod);
}

int schnorr()
{

    int p = 37;
    int q = 43;

    int a = 9;
    int res = mod_pow(a, q, p);
    while (res != 1)
    {
        a = rand() % 100 + 11;
        res = mod_pow(a, q, p);
    }

    int s = 31;

    int v = mod_pow(a, -s, p);

    int r = 1 + rand() % (q - 1);

    int x = mod_pow(a, r, p);

    string msg = "10110110";

    string x_str = integerToBinary(x);

    string e = hash_function(msg + x_str);

    long long y = r + mod_mul(s, binaryToInteger(e), q);

    cout << "e = " << e << endl;
    cout << "y = " << y << endl;

    long long x1 = mod_mul(mod_pow(a, y, p), mod_pow(v, binaryToInteger(e), q), q);

    string x1_str = integerToBinary(x1);
    string e1 = hash_function(msg+x1_str);

    cout<<"e1 = "<<e1;
}

int main()
{
    srand(time(0));

    // cout << binaryToInteger("1011");
    schnorr();
    return 0;
}