#include <bits/stdc++.h>
using namespace std;

vector<vector<vector<int>>> s;
vector<int> initial_perm;
vector<int> key_comp;
vector<int> p_box;
vector<int> final_perm;
vector<int> shift_table;

string
populateString(string s) // if size of a block is less than 64
{                        // this function will make it to 64 bit by pushing randome bits

    while (s.size() < 64)
    {
        s.push_back('0' + rand() % 2);
    }
    return s;
}

string binary_generate(int n) // function will generate binary string of n size
{
    string res = "";
    while (n--)
    {
        res.push_back('0' + rand() % 2);
    }

    return res;
}

vector<int> reversePermutation(vector<int> &permutation) // reverse the mapping of permutation
{                                                        //  {a->b} to {b->a}
    vector<int> resultKey(permutation.size());

    for (int i = 0; i < permutation.size(); i++)
    {
        resultKey[permutation[i] - 1] = i + 1;
    }
    return resultKey;
}

vector<int> generate_permutation(int n) // generate a random permutation of n size of numbers {1 - n}
{
    unordered_map<int, bool> generated;
    vector<int> res;
    for (int i = 0; i < n; i++)
    {
        int num = rand() % n + 1;

        while (generated.find(num) != generated.end())
        {
            num = rand() % n + 1;
        }
        generated[num] = true;
        res.push_back(num);
    }

    return res;
}

string key_64_to_56(string key) // to reduce 64 bit key to 56 bit by discarding 8 bits
{
    string key_56 = "";
    for (int i = 0; i < 64; i++)
    {
        if (i % 8 != 7)
        {
            key_56.push_back(key[i]);
        }
    }
    return key_56;
}

vector<vector<vector<int>>> generate_S_boxes() // generate 8 s boxes
{
    vector<vector<vector<int>>> s(8);

    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            vector<int> temp;
            unordered_map<int, bool> generated;

            for (int k = 0; k < 16; k++)
            {
                int num = rand() % 16;

                while (generated.find(num) != generated.end())
                {
                    num = rand() % 16;
                }
                generated[num] = true;
                temp.push_back(num);
            }
            s[i].push_back(temp);
        }
    }
    return s;
}

string permute(string k, vector<int> &arr, int n) // for arranging string as per permutation given
{
    string perumutation = "";
    for (int i = 0; i < n; i++)
    {
        perumutation.push_back(k[arr[i] - 1]);
    }
    return perumutation;
}

string shift_left(string str, int shifts) // for shifting string by "shifts" number of bits
{
    string res = "";
    for (int i = 0; i < shifts; i++)
    {
        for (int j = 1; j < 28; j++)
        {
            res.push_back(str[j]);
        }
        res.push_back(str[0]);
        str = res;
        res = "";
    }
    return str;
}

string xor_(string s1, string s2) // xor of two binary strings
{
    string ans = "";
    for (int i = 0; i < s1.size(); i++)
    {
        if (s1[i] == s2[i])
        {
            ans += "0";
        }
        else
        {
            ans += "1";
        }
    }
    return ans;
}
string encrypt(string pt, vector<string> rkb)
{

    // Initial Permutation of plaintext
    pt = permute(pt, initial_perm, 64);

    // Splitting plaitext into two half
    string left = pt.substr(0, 32);
    string right = pt.substr(32, 32);

    // Expansion D-box Table
    // for expanding 32 bit half to 48 bits
    vector<int> exp_d = {32, 1, 2, 3, 4, 5, 4, 5, 6, 7, 8, 9,
                         8, 9, 10, 11, 12, 13, 12, 13, 14, 15, 16, 17,
                         16, 17, 18, 19, 20, 21, 20, 21, 22, 23, 24, 25,
                         24, 25, 26, 27, 28, 29, 28, 29, 30, 31, 32, 1};

    for (int i = 0; i < 16; i++)
    {
        string right_expanded = permute(right, exp_d, 48);

        // XOR RoundKey[i] and right_expanded
        string res = xor_(rkb[i], right_expanded);

        // S-boxes   converting 6 bits into 4 bits
        string converted_bits = "";
        for (int i = 0; i < 8; i++)
        {
            int row = 2 * int(res[i * 6] - '0') + int(res[i * 6 + 5] - '0');
            int col = 8 * int(res[i * 6 + 1] - '0') + 4 * int(res[i * 6 + 2] - '0') + 2 * int(res[i * 6 + 3] - '0') + int(res[i * 6 + 4] - '0');
            int val = s[i][row][col];
            converted_bits.push_back(char(val / 8 + '0'));
            val = val % 8;
            converted_bits.push_back(char(val / 4 + '0'));
            val = val % 4;
            converted_bits.push_back(char(val / 2 + '0'));
            val = val % 2;
            converted_bits.push_back(char(val + '0'));
        }
        // Straight D-box
        converted_bits = permute(converted_bits, p_box, 32);

        // XOR left and op
        res = xor_(converted_bits, left);

        left = res;

        // Swapping
        if (i != 15)
        {
            swap(left, right);
        }
    }

    string combine = left + right;

    // Final Permutation
    string cipher = permute(combine, final_perm, 64);
    return cipher;
}

string encryption(string plaintext, string key)
{
    plaintext = populateString(plaintext);

    // Splitting key
    string left = key.substr(0, 28);
    string right = key.substr(28, 28);

    vector<string> rkb; // Roundkeys

    for (int i = 0; i < 16; i++)
    {
        // Shifting
        left = shift_left(left, shift_table[i]);
        right = shift_left(right, shift_table[i]);

        // Combining
        string combine = left + right;

        // Key Compression 56 bits to 48 bits
        string RoundKey = permute(combine, key_comp, 48);

        rkb.push_back(RoundKey);
    }

    string cipher = encrypt(plaintext, rkb);

    return cipher;
}

string decryption(string ciphertext, string key)
{
    int original_size = ciphertext.size();

    // Splitting
    string left = key.substr(0, 28);
    string right = key.substr(28, 28);

    vector<string> rkb; // Roundkeys

    for (int i = 0; i < 16; i++)
    {
        // Shifting
        left = shift_left(left, shift_table[i]);
        right = shift_left(right, shift_table[i]);

        // Combining
        string combine = left + right;

        // Key Compression
        string RoundKey = permute(combine, ::key_comp, 48);

        rkb.push_back(RoundKey);
    }

    // reversing keys due to decryption process
    reverse(rkb.begin(), rkb.end());
    string text = encrypt(ciphertext, rkb);

    return text;
}

int main()
{
    srand(time(0));

    string plaintext, key;
    plaintext = binary_generate(rand() % 256 + 100); // generating random plaintext
    cout << "\nfull plaintext = " << plaintext << "\n";
    cout << "size = " << plaintext.size() << endl;

    int blocks = plaintext.size() / 64 + 1; // computing no. of blocks
    key = binary_generate(64);              // generating random key of 64 key

    key = key_64_to_56(key); // converting 64 bit key to 56 by dicarding 8 bits

    s = generate_S_boxes();                        // generating 8 s boxes
    key_comp = generate_permutation(56);           // generating key_compression table
    initial_perm = generate_permutation(64);       // generating initial permutation table
    p_box = generate_permutation(32);              // generating permuation table
    final_perm = reversePermutation(initial_perm); // generating final permuation table by reversing initial permutation table
    shift_table = {1, 1, 2, 2, 2, 2, 2, 2,         // sfifting table
                   1, 2, 2, 2, 2, 2, 2, 1};

    int bl = 1; // encryption of blocks
    while (bl <= blocks)
    {
        string blockPlaintext = plaintext.substr(64 * (bl - 1), 64); // extracting 64 bit block from plaintext

        cout << "\nencryption of block - " << bl << "\n";
        cout << "plaintext           = " << blockPlaintext << endl;
        string ciphertext = encryption(blockPlaintext, key); // encryption
        cout << "ciphertext          = " << ciphertext << endl;
        string decryptedPlaintext = decryption(ciphertext, key); // decryption
        cout << "decryptedPlaintext  = " << decryptedPlaintext.substr(0, blockPlaintext.size()) << endl;
        bl++;
    }
}
