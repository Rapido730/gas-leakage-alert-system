#include <iostream>
#include <bitset>
#include <string>
#include <sstream>
#include <gmpxx.h>
#include "./hash_utility.hpp"
#define QLength 256
#define PLength 1024
using namespace std;

string BinaryToString(string Bin)
{
    std::string binary_string = Bin;
    std::stringstream ss(binary_string);

    // Convert binary to string
    std::string output_string;
    while (ss.good())
    {
        std::bitset<8> bits;
        ss >> bits;
        output_string += static_cast<char>(bits.to_ulong());
    }

    return output_string;
}

string StringToBinary(string msg)
{
    std::string input_string = msg;
    std::bitset<8> binary_bits(input_string[0]);

    // Convert string to binary
    for (size_t i = 1; i < input_string.size(); i++)
    {
        binary_bits <<= 8;
        binary_bits |= std::bitset<8>(input_string[i]);
    }
    string binary_string = binary_bits.to_string();

    return binary_string;
}

void key_generation(mpz_class &a, mpz_class &private_key, mpz_class &public_key, mpz_class &p, mpz_class &q)
{
    gmp_randclass rr(gmp_randinit_default);
    rr.seed(time(NULL));
    mpz_class v;
    // This method is going to prevent q overflow
    q = 1;
    mpz_mul_2exp(q.get_mpz_t(), q.get_mpz_t(), QLength - 1); // shift to QLength
    q += rr.get_z_bits(QLength - 2);
    mpz_nextprime(q.get_mpz_t(), q.get_mpz_t());

    // p = q*n + 1 and should be a PLength-long prime
    p = 1;
    mpz_mul_2exp(p.get_mpz_t(), p.get_mpz_t(), PLength - 1); // shift to PLength
    mpz_class n = p / q;
    while (true)
    {
        p = q * n + 1;
        if (mpz_probab_prime_p(p.get_mpz_t(), 25) > 0)
            break;
        n++;
    }

    // a^q % p = 1
    // so first, a = temp^n % p, a > 1
    mpz_class temp = 2;
    while (true)
    {
        mpz_powm(a.get_mpz_t(), temp.get_mpz_t(), n.get_mpz_t(), p.get_mpz_t());
        if (a > 1)
            break;
        temp++;
    }

    // for verification
    mpz_powm(temp.get_mpz_t(), a.get_mpz_t(), q.get_mpz_t(), p.get_mpz_t());
    if (temp != 1)
    {
        cerr << "error";
        exit(-1);
    }

    // private key 0 < s < q

    private_key = rr.get_z_bits(rand() % (QLength * 2 / 3 - 1) + QLength / 3);

    // a^-s % p = v   where s is private key
    mpz_class s_temp = -private_key;
    mpz_powm(v.get_mpz_t(), a.get_mpz_t(), s_temp.get_mpz_t(), p.get_mpz_t());

    public_key = v;
}

pair<mpz_class, mpz_class> generate_signature(mpz_class a, mpz_class p, mpz_class q, mpz_class private_key, string Msg)
{

    mpz_class r, x, e, y;

    gmp_randclass rr(gmp_randinit_default);
    rr.seed(time(NULL));

    r = rr.get_z_bits(rand() % (QLength * 2 / 3 - 1) + QLength / 3);

    // x = a^r % p
    mpz_powm(x.get_mpz_t(), a.get_mpz_t(), r.get_mpz_t(), p.get_mpz_t());

    string res = hash_function(Msg + x.get_str(2));

    mpz_set_str(e.get_mpz_t(), res.c_str(), 2);

    y = (r + private_key * e) % q;
    cout << "e = " << e << "\n\n";
    cout << "y = " << y << "\n\n";
    return {e, y};
}

void verify(mpz_class a, mpz_class public_key, mpz_class p, mpz_class e, mpz_class y, string Msg)
{
    mpz_class x1, temp;

    mpz_powm(temp.get_mpz_t(), a.get_mpz_t(), y.get_mpz_t(), p.get_mpz_t());
    mpz_powm(x1.get_mpz_t(), public_key.get_mpz_t(), e.get_mpz_t(), p.get_mpz_t());
    x1 = (x1 * temp) % p;

    string res = hash_function(Msg + x1.get_str(2));

    mpz_class e1;
    mpz_set_str(e1.get_mpz_t(), res.c_str(), 2);

    if (e1 == e)
    {
        cout << "Signature verified\n\n";
    }
    else
    {
        cout << "Signature not verified\n\n";
    }
}

int main()
{

    mpz_class p, q, a, private_key, public_key;

    key_generation(a, private_key, public_key, p, q);

    cout << "Private Key = " << private_key << "\n\n";
    cout << "Private Key = " << public_key << "\n\n";

    string Msg;
    cout << "Enter your message = ";
    cin >> Msg;

    string Msg_Bin = StringToBinary(Msg);

    pair<mpz_class, mpz_class> signed_document = generate_signature(a, p, q, private_key, Msg_Bin);

    mpz_class e = signed_document.first; // i tried by adding one to e it result in
                                         // signature not verified
    mpz_class y = signed_document.second;

    verify(a, public_key, p, e, y, Msg_Bin);

    return 0;
}