
#include <bits/stdc++.h>
using namespace std;

int xgcd(int a, int b, int &x, int &y)
{
	// Base Case
	if (a == 0)
	{
		x = 0;
		y = 1;
		return b;
	}

	int x1, y1;
	int gcd = xgcd(b % a, a, x1, y1);

	x = y1 - (b / a) * x1;
	y = x1;

	return gcd;
}

int inv(int a, int b)
{
	int X, Y;
	xgcd(a, b, X, Y);

	X = (X + 26) % 26;
	return X;
}

int gcd(int a, int b)
{
	if (a == 0)
	{
		return b;
	}

	return gcd(b % a, a);
}

string decrypt(string s, int a, int b)
{
	int n = s.length();
	int aInv = inv(a, 26);

	for (int i = 0; i < n; i++)
	{
		int c = s[i] - 'a';

		int m = (((c - b + 26) % 26) * aInv) % 26;

		s[i] = char(m + 'a');
	}

	return s;
}

pair<int, int> cryptAnalysisUtil(int firstHighestFrequency, int secondHighestFrequency, int flag)
{

	int a1 = 'e' - 'a';
	int c1 = firstHighestFrequency;
	int a2 = 't' - 'a';
	int c2 = secondHighestFrequency;

	if (flag == 1)
	{
		swap(a1, a2);
	}
	int c = (c1 - c2 + 26) % 26;
	int a = (a2 - a1 + 26) % 26;

	int aInverse = inv(a, 26);

	int aKey = (c * aInverse) % 26;

	if (gcd(aKey, 26) == 1)
	{
		int bKey = (firstHighestFrequency - aKey * a1 + 26);

		if (bKey < 0)
		{
			while (bKey < 0)
			{
				bKey += 26;
			}
		}

		bKey = bKey % 26;

		// cout << aKey << " " << bKey << endl;
		return {aKey, bKey};
	}

	return {-1, -1};
}

string cryptAnalysis(string cipher)
{
	vector<int> freq(26, 0);

	for (char c : cipher)
	{
		freq[c - 'a']++;
	}

	priority_queue<pair<int, int>> pq;

	for (int i = 0; i < 26; i++)
	{
		pq.push({freq[i], i});
	}

	int firstHighestFrequency = pq.top().second;
	pq.pop();
	pair<int, int> key;
	while (!pq.empty())
	{
		int secondHighestFrequency = pq.top().second;
		// cout << secondHighestFrequency << endl;
		pq.pop();
		key = cryptAnalysisUtil(firstHighestFrequency, secondHighestFrequency, 0);
		pair<int, int> temp = {-1, -1};
		if (key != temp)
		{
			string plainText = decrypt(cipher, key.first, key.second);
			cout << "\nplainText = " << plainText << endl;
			int flag;
			cout << "\nWhether the text is meaningful or not? enter 1 for yes and 0 for no\n";
			cin >> flag;

			if (flag == 1)
			{
				printf("\n mission successful \n key = {%d,%d}\n", key.first, key.second);
				return plainText;
				break;
			}

			cout << "Lets try again \n";
		}
	}

	for (int i = 0; i < 26; i++)
	{
		pq.push({freq[i], i});
	}

	firstHighestFrequency = pq.top().second;
	pq.pop();
	while (!pq.empty())
	{
		int secondHighestFrequency = pq.top().second;
		// cout << secondHighestFrequency << endl;
		pq.pop();
		key = cryptAnalysisUtil(firstHighestFrequency, secondHighestFrequency, 1);
		pair<int, int> temp = {-1, -1};
		if (key != temp)
		{
			string plainText = decrypt(cipher, key.first, key.second);
			cout << "\nplainText = " << plainText << endl;
			int flag;
			cout << "\nWhether the text is meaningful or not? enter 1 for yes and 0 for no\n";
			cin >> flag;

			if (flag == 1)
			{
				printf("\n mission successful \n key = {%d,%d}\n", key.first, key.second);
				return plainText;
				break;
			}

			cout << "Lets try again \n";
		}
	}

	return cipher;
}

int main()
{
	cout << "Enter cipher text = ";
	string cipher;
	cin >> cipher;
	cout << "\nCiphertext = " << cipher << endl;
	cryptAnalysis(cipher);

	return 0;
}
