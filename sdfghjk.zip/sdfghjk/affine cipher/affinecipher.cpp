
#include <bits/stdc++.h>
using namespace std;

int xgcd(int a, int b, int &x, int &y)
{
    // Base Case
    if (a == 0)
    {
        x = 0;
        y = 1;
        return b;
    }

    int x1, y1;
    int gcd = xgcd(b % a, a, x1, y1);

    x = y1 - (b / a) * x1;
    y = x1;

    return gcd;
}

int inv(int a, int b)
{
    int X, Y;
    xgcd(a, b, X, Y);

    X = (X + 26) % 26;
    return X;
}

int gcd(int a, int b)
{
    if (a == 0)
    {
        return b;
    }

    return gcd(b % a, a);
}
// Driver Code

string encrypt(string s, int a, int b)
{
    if (gcd(a, 26) != 1)
        return s;
    int n = s.length();

    for (int i = 0; i < n; i++)
    {
        char c = s[i];
        int m = c - 'a';

        int e = (a * m + b) % 26;

        s[i] = char(e + 'a');
    }

    return s;
}

string decrypt(string s, int a, int b)
{
    int n = s.length();
    int aInv = inv(a, 26);

    for (int i = 0; i < n; i++)
    {
        int c = s[i] - 'a';

        int m = (((c - b + 26) % 26) * aInv) % 26;

        s[i] = char(m + 'a');
    }

    return s;
}

int main()
{
    int x, y, a, b;
    cout << "Enter plain text = ";
    string s;
    cin >> s;
    cout << "Enter Secret Key {a,b} = ";
    cin >> a >> b;

    string cipher = encrypt(s, a, b);
    if (cipher == s)
    {
        cout << "change value of a";
        return 0;
    }
    cout << "\nCiphertext = " << cipher << endl;
    string plain = decrypt(cipher, a, b);
    cout << "\nplaintext = " << plain << endl;

    return 0;
}
