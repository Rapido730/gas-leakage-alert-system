#include <bits/stdc++.h>
using namespace std;

int gcd_extended(int a, int b, int &X, int &Y)
{
    if (a == 0)
    {
        X = 0;
        Y = 1;
        return b;
    }
    int X1, Y1;
    int gcd = gcd_extended(b % a, a, X1, Y1);
    cout << X1 << " " << Y1 << endl;
    X = Y1 - X1 * (b / a);
    Y = X1;

    return gcd;
}

int main()
{
    int X, Y;
    int a, b;

    cin >> a >> b;

    if (a < b)
    {
        swap(a, b);
    }

    printf("gcd(%d,%d) = %d", a, b, gcd_extended(a, b, X, Y));
    printf("\nX = %d and Y= %d ", X, Y);
}
