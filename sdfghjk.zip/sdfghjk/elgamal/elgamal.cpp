#include <bits/stdc++.h>
using namespace std;

int mod_mul(int a, int b, int mod)
{

    return ((a % mod) * (b % mod)) % mod;
}

int mod_pow(int x, int y, int mod)
{

    if (y == 0)
    {
        return 1;
    }
    int flag = 0;
    int ans = mod_pow(x, y / 2, mod);
    if (y % 2)
    {
        return mod_mul(mod_mul(ans, ans, mod), x, mod);
    }

    return mod_mul(ans, ans, mod);
}

int gcd_extended(int a, int b, int &X, int &Y)
{
    if (a == 0)
    {
        X = 0;
        Y = 1;
        return b;
    }
    int X1, Y1;
    int gcd = gcd_extended(b % a, a, X1, Y1);

    X = Y1 - X1 * (b / a);
    Y = X1;

    return gcd;
}

int getInv(int num, int mod)
{

    int X;
    int Y;

    gcd_extended(num, mod, X, Y);

    while (X < 0)
    {
        X = (X + mod) % mod;
    }
    return X;
}
pair<int, vector<int>> encryption(string plaintext, int q, int g, int h)
{

    vector<int> ciphertext;

    int k = 7;

    int p = mod_pow(g, k, q);

    int s = mod_pow(h, k, q);

    for (int i = 0; i < plaintext.size(); i++)
    {
        int c = mod_mul((plaintext[i] - 'a'), s, q);
        ciphertext.push_back(c);
    }
    return {p, ciphertext};
}

string decryption(int p, vector<int> &ciphertext, int q, int a)
{

    int _s = mod_pow(p, a, q);
    string plaintext = "";
    for (int c : ciphertext)
    {

        int pt = mod_mul(c, getInv(_s, q), q);
        plaintext.push_back(pt + 'a');
    }

    return plaintext;
}

int main()
{

    int q = 59;

    int a = 5; // private key

    int g = 3;

    int h = mod_pow(g, a, q);

    // {q,g,h} public key          {a} private key

    string plaintext;

    cout << "\n\nEnter plaintext : ";
    cin >> plaintext;

    pair<int, vector<int>> ciphertext = encryption(plaintext, q, g, h);

    cout << "Ciphertext : ";
    for (int i : ciphertext.second)
    {
        cout << i;
    }
    cout << endl;

    int p = ciphertext.first;
    vector<int> c = ciphertext.second;

    string decryptedText = decryption(p, c, q, a);
    cout << "Decrypted plaintext : ";
    cout << decryptedText;

    return 0;
}