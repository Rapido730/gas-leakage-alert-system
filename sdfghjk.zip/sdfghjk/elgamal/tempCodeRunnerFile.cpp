int gcd_extended(int a, int b, int &X, int &Y)
{
    if (a == 0)
    {
        X = 0;
        Y = 1;
        return b;
    }
    int X1, Y1;
    int gcd = gcd_extended(b % a, a, X1, Y1);

    X = Y1 - X1 * (b / a);
    Y = X1;

    return gcd;
}


int getInv(int num,int mod){

    int X;
    int Y;

    gcd_extended(num,mod,X,Y);

    cout<<X<<" "<<Y;
    return X;
}