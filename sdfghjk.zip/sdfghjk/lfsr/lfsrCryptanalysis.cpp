#include <bits/stdc++.h>

using namespace std;

void utilityCombination(vector<vector<int>> &combinations, vector<int> &arr, int ind)
{
    if (ind == arr.size())
        return;
    combinations.push_back(arr);

    utilityCombination(combinations, arr, ind + 1);
    arr[ind] = 1;
    utilityCombination(combinations, arr, ind + 1);
}

vector<vector<int>> allCombination(int n)
{
    vector<int> arr(n, 0);
    vector<vector<int>> ans;
    utilityCombination(ans, arr, 0);
    return ans;
}

int LFSRshifter(vector<int> &cArray, vector<int> &bArray)
{
    int xor_value = 0;
    for (int i = 0; i < bArray.size(); i++)
    {
        xor_value ^= cArray[i] * bArray[i];
    }
    int nextBit = bArray[0];
    bArray.erase(bArray.begin());
    bArray.push_back(xor_value);
    return nextBit;
}

vector<int> keyStreamgenerator(int n, vector<int> cArray, vector<int> bArray)
{
    vector<int> keyStream(n, 0);
    for (int i = 0; i < n; i++)
    {
        keyStream[i] = LFSRshifter(cArray, bArray);
    }
    return keyStream;
}

string encrypt(string plaintext, vector<int> key)
{
    string ciphertext;
    for (int i = 0; i < plaintext.length(); i++)
    {
        int cipher_char = int(plaintext[i] - '0') ^ key[i];
        ciphertext.push_back(char('0' + cipher_char % 2));
    }
    return ciphertext;
}

string decrypt(string ciphertext, vector<int> key)
{
    string plaintext;
    for (int i = 0; i < ciphertext.length(); i++)
    {
        int plain_char = int(ciphertext[i] - '0') ^ key[i];
        plaintext.push_back(char('0' + plain_char % 2));
    }
    return plaintext;
}

bool cryptanalysis(string plaintext, string ciphertext)
{
    vector<int> guessedKeystream;
    for (int i = 0; i < plaintext.size(); i++)
    {
        int num = (int(plaintext[i] - '0') + int(ciphertext[i] - '0')) % 2;
        guessedKeystream.push_back(num);
    }

    int size = guessedKeystream.size();
    vector<int> finalCArray;
    vector<int> guessedSeed;
    bool flag = false;
    for (int i = 0; i < size; i++)
    {
        guessedSeed.push_back(guessedKeystream[i]);

        
        vector<vector<int>> CArray = allCombination(guessedSeed.size());

        for (int j = 0; j < CArray.size(); j++)
        {
            vector<int> generatedKeyStream = keyStreamgenerator(size, CArray[j], guessedSeed);
            if (generatedKeyStream == guessedKeystream)
            {
                finalCArray = CArray[j];
                cout << "\nHurray!!! attack successful \n\n";

                cout << "Seed  =            ";
                for (int i : guessedSeed)
                {
                    cout << i;
                }
                cout << endl;
                cout << "Ci   =             ";
                for (int i : CArray[j])
                {
                    cout << i;
                }
                cout << endl;

                flag = true;

                cout << " \nattacked decrypt text = " << decrypt(ciphertext, generatedKeyStream) << endl;

                break;
            }
        }
        if (flag)
            break;
    }

    if (!flag)
    {
        cout << "failed";
    }

    return false;
}

int main()
{
    srand(time(0));
    string plaintext;
    string ciphertext;
    cout << "Enter known plaintext = ";
    cin >> plaintext;
    cout << "\nEnter known ciphertext = ";
    cin >> ciphertext;
    cout << endl;

    cryptanalysis(plaintext, ciphertext);

    return 0;
}
