#include <bits/stdc++.h>

using namespace std;

vector<int> bArray; // initial seed for LFSR
vector<int> cArray; // 0 or 1 of this array will defined whether the bit of taht index will participate in xor operation or not.

void seedGenerator(int n)
{

    while (n--)
    {
        bArray.push_back(rand() % 2);
        cArray.push_back(rand() % 2);
    }
}

int LFSRshifter()
{
    int xor_value = 0;
    for (int i = 0; i < bArray.size(); i++)
    {
        xor_value ^= cArray[i] * bArray[i];
    }
    int nextBit = bArray[0];
    bArray.erase(bArray.begin());
    bArray.push_back(xor_value);
    return nextBit;
}

vector<int> keyStreamgenerator(int n)
{
    vector<int> keyStream(n, 0);
    for (int i = 0; i < n; i++)
    {
        keyStream[i] = LFSRshifter();
    }
    return keyStream;
}

string encrypt(string plaintext, vector<int> key)
{
    string ciphertext;
    for (int i = 0; i < plaintext.length(); i++)
    {
        int cipher_char = int(plaintext[i] - '0') ^ key[i];
        ciphertext.push_back(char('0' + cipher_char % 2));
    }
    return ciphertext;
}

string decrypt(string ciphertext, vector<int> key)
{
    string plaintext;
    for (int i = 0; i < ciphertext.length(); i++)
    {
        int plain_char = int(ciphertext[i] - '0') ^ key[i];
        plaintext.push_back(char('0' + plain_char % 2));
    }
    return plaintext;
}

int main()
{
    srand(time(0));
    string plaintext;
    cout << "Enter plain text = ";
    cin >> plaintext;
    seedGenerator(rand() % 6 + 4);
    cout << "Seed  =            ";
    for (int i : bArray)
    {
        cout << i;
    }
    cout << endl;
    cout << "Ci =               ";
    for (int i : cArray)
    {
        cout << i;
    }
    cout << endl;
    vector<int> keyStream = keyStreamgenerator(plaintext.size());

    string ciphertext = encrypt(plaintext, keyStream);
    string decryptedPlaintext = decrypt(ciphertext, keyStream);
    cout << "Key =              ";
    for (int i : keyStream)
    {
        cout << i;
    }
    cout << endl;
    cout << "Ciphertext =       " << ciphertext << endl;
    cout << "Decrypted text =   " << decryptedPlaintext << endl;
    // cout << "Plaintext =        " << plaintext << endl;

    return 0;
}
