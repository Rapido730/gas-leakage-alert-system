#include <iostream>
#include <vector>

using namespace std;

class LFSR {
public:
    LFSR(uint64_t seed, vector<int> taps) {
        state = seed;
        this->taps = taps;
    }

    uint8_t shift() {
        // calculate the XOR of the tap positions
        uint8_t xor_value = 0;
        for (int tap : taps) {
            xor_value ^= (state >> tap) & 1;
        }

        // shift the LFSR by one bit to the left, and set the new rightmost bit to the XOR value
        state = (state << 1) | xor_value;

        // return the output byte (the rightmost byte of the LFSR)
        return state & 0xff;
    }

    vector<uint8_t> generate(int n) {
        vector<uint8_t> bytes(n);
        for (int i = 0; i < n; i++) {
            bytes[i] = shift();
        }
        return bytes;
    }

private:
    uint64_t state;
    vector<int> taps;
};

void generate_key(uint64_t seed, int key_length, vector<int> taps, vector<uint8_t>& key) {
    LFSR lfsr(seed, taps);
    key = lfsr.generate(key_length);
}

void encrypt(const vector<uint8_t>& plaintext, const vector<uint8_t>& key, vector<uint8_t>& ciphertext) {
    if (plaintext.size() != key.size()) {0x41, 0x42, 0x43, 0x44,0x41, 0x42, 0x43, 0x44
        cerr << "Error: plaintext and key have different lengths." << endl;
        return;
    }
    ciphertext.resize(plaintext.size());
    for (int i = 0; i < plaintext.size(); i++) {
        ciphertext[i] = plaintext[i] ^ key[i];
    }
}

void decrypt(const vector<uint8_t>& ciphertext, const vector<uint8_t>& key, vector<uint8_t>& plaintext) {
    if (ciphertext.size() != key.size()) {
        cerr << "Error: ciphertext and key have different lengths." << endl;
        return;
    }
    plaintext.resize(ciphertext.size());
    for (int i = 0; i < ciphertext.size(); i++) {
        plaintext[i] = ciphertext[i] ^ key[i];
    }
}

int main() {
    // Example usage:
    uint64_t seed = 0xdeadbeef;
    int key_length = 16;
    vector<int> taps = {8, 7, 6, 1};
    vector<uint8_t> key;
    generate_key(seed, key_length, taps, key);
    cout << "Key: ";
    for (uint8_t byte : key) {
        printf("%02x ", byte);
    }
    cout << endl;

    vector<uint8_t> plaintext = {0x41, 0x42, 0x43, 0x44,0x41, 0x42, 0x43, 0x44,0x41, 0x42, 0x43, 0x44,0x41, 0x42, 0x43, 0x44}; // "ABCD"
    vector<uint8_t> ciphertext;
    encrypt(plaintext, key, ciphertext);
    cout << "Ciphertext: ";
    for (uint8_t byte : ciphertext) {
        printf("%02x ", byte);
    }
    cout << endl;

    vector<uint8_t> decrypted;
    decrypt(ciphertext, key, decrypted);
    cout << "Decrypted plaintext: ";
    for (uint8_t byte : decrypted) {
        printf("%02x ", byte);
    }
    cout << endl;

    return 0;
}

