#ifndef AES_Encryption_HPP
#define AES_Encryption_HPP

#include <bits/stdc++.h>

using namespace std;

string xor_op(string a, string b)
{
    string ans = "";
    for (int i = 0; i < a.size(); i++)
    {
        if (a[i] == b[i])
        {
            ans.push_back('0');
        }
        else
        {
            ans.push_back('1');
        }
    }

    return ans;
}

string integerToBinary(int num)
{
    string ans;

    int temp = num % 2;

    while (num)
    {
        ans.push_back('0' + num % 2);
        num = num / 2;
    }

    while (ans.size() < 4)
    {
        ans.push_back('0');
    }

    reverse(ans.begin(), ans.end());

    return ans;
}
string HexaToBin(string hexa)
{
    string ans = "";

    for (char c : hexa)
    {

        if (c <= '9')
            ans += integerToBinary(c - '0');
        else
        {
            ans += integerToBinary(c - 'a' + 10);
        }
    }

    return ans;
}
char IntToHexa(int temp)
{

    if (temp < 10)
    {
        return ('0' + temp);
    }
    return ('a' + temp - 10);
}
string BinToHexa(string msg)
{

    string hexa = "";
    int n = msg.length() - 1;
    while (n)
    {

        int temp = 0;
        int exp = 1;
        int len = n;

        for (int i = len; i > max(len - 4, 0); i--)
        {

            temp += (msg[i] - '0') * exp;
            exp *= 2;
        }

        hexa.push_back(IntToHexa(temp));
        n = max(n - 4, 0);
    }

    reverse(hexa.begin(), hexa.end());

    return hexa;
}
void applyMod2(vector<int> &a)
{
    int n = a.size();
    for (int i = 0; i < n; i++)
    {
        if (a[i] < 0)
            a[i] = (-a[i]);
        a[i] %= 2;
    }
    while (a.size() > 0 && a.back() == 0)
        a.pop_back();
}
vector<int> Sub_Pol(vector<int> poly1, vector<int> poly2)
{
    int len = max(poly1.size(), poly2.size());
    vector<int> res;
    for (int ind = 0; ind < len; ind++)
    {
        if (ind < poly1.size() && ind < poly2.size())
        {
            res.push_back(poly1[ind] - poly2[ind]);
        }
        else if (ind < poly1.size())
        {
            res.push_back(poly1[ind]);
        }
        else
        {
            res.push_back(poly2[ind]);
        }
    }
    return res;
}
vector<int> Mul_Pol(vector<int> poly1, vector<int> poly2)
{
    int len1 = poly1.size(), len2 = poly2.size();

    vector<int> res(len1 + len2 - 1);
    for (int i = 0; i < len1; i++)
    {
        for (int j = 0; j < len2; j++)
        {
            res[i + j] += poly1[i] * poly2[j];
        }
    }
    return res;
}

vector<vector<int>> Div_Pol(vector<int> a, vector<int> b)
{
    int n = b.size();
    vector<int> q = vector<int>(a.size() - n + 1);
    while (a.size() >= n)
    {
        int coef = a.back() / b.back();
        int deg = a.size() - b.size();
        q[deg] = coef;
        q[deg] %= 2;
        for (int i = 0; i < n; i++)
        {
            a[a.size() - 1 - i] -= coef * b[b.size() - 1 - i];
        }
        while (a.size() > 0 && a.back() == 0)
            a.pop_back();
    }
    return {q, a};
}

vector<int> GetInv(vector<int> a, vector<int> b, vector<int> t1, vector<int> t2)
{
    if (b.size() == 0)
    {
        return t1;
    }
    if (b.size() == 1 && b[0] == 0)
    {
        return t1;
    }
    vector<int> q, r;
    vector<vector<int>> tmp = Div_Pol(a, b);

    q = tmp[0], r = tmp[1];
    applyMod2(q);
    applyMod2(r);
    vector<int> t;
    vector<int> tmpMul = Mul_Pol(q, t2);
    applyMod2(tmpMul);
    t = Sub_Pol(t1, tmpMul);
    applyMod2(t);
    return GetInv(b, r, t2, t);
}
char Int_To_Hexa(int val)
{
    if (val >= 0 && val <= 9)
        return (val + '0');
    if (val == 10)
        return 'a';
    else if (val == 11)
        return 'b';
    else if (val == 12)
        return 'c';
    else if (val == 13)
        return 'd';
    else if (val == 14)
        return 'e';
    else
        return 'f';
}
int Hexa_To_Int(char a)
{
    int val = 0;
    if (isdigit(a))
        val = a - '0';
    else
    {
        if (a == 'a')
            val = 10;
        else if (a == 'b')
            val = 11;
        else if (a == 'c')
            val = 12;
        else if (a == 'd')
            val = 13;
        else if (a == 'e')
            val = 14;
        else
            val = 15;
    }
    return val;
}
vector<int> Hex_To_Binary(char a)
{
    int val = 0;
    if (isdigit(a))
        val = a - '0';
    else
    {
        if (a == 'a')
            val = 10;
        else if (a == 'b')
            val = 11;
        else if (a == 'c')
            val = 12;
        else if (a == 'd')
            val = 13;
        else if (a == 'e')
            val = 14;
        else
            val = 15;
    }
    vector<int> res(4, 0);
    if (val > 15)
        return res;
    int ind = 3;
    while (val > 0)
    {

        res[ind] = val % 2;
        val = val / 2;
        ind--;
    }

    return res;
}
vector<int> changepoly(vector<int> &a)
{
    while (a.size() > 0 && a.back() == 0)
    {
        a.pop_back();
    }
    if (a.size() == 0)
        a.push_back(0);
    return a;
}
vector<vector<string>> sboxCreation(vector<vector<string>> s)
{
    vector<vector<int>> matrix = {
        {1, 0, 0, 0, 1, 1, 1, 1},
        {1, 1, 0, 0, 0, 1, 1, 1},
        {1, 1, 1, 0, 0, 0, 1, 1},
        {1, 1, 1, 1, 0, 0, 0, 1},
        {1, 1, 1, 1, 1, 0, 0, 0},
        {0, 1, 1, 1, 1, 1, 0, 0},
        {0, 0, 1, 1, 1, 1, 1, 0},
        {0, 0, 0, 1, 1, 1, 1, 1}};

    vector<vector<string>> sdash(4, vector<string>(4, ""));
    vector<int> y = {1, 1, 0, 0, 0, 1, 1, 0};

    for (int row = 0; row < 4; row++)
    {
        for (int col = 0; col < 4; col++)
        {
            string cur = s[row][col];

            vector<int> firstHalf = Hex_To_Binary(cur[0]), secondHalf = Hex_To_Binary(cur[1]);
            vector<int> b;
            for (auto it : firstHalf)
            {
                b.push_back(it);
            }
            for (auto it : secondHalf)
            {

                b.push_back(it);
            }
            reverse(b.begin(), b.end());
            b = changepoly(b);

            vector<int> c = {1, 1, 0, 1, 1, 0, 0, 0, 1};
            vector<int> t1 = {0}, t2 = {1};
            vector<int> mi = GetInv(c, b, t1, t2);

            while (mi.size() < 8)
            {
                mi.push_back(0);
            }

            vector<int> multires;

            for (int i = 0; i < 8; i++)
            {
                int value = 0;
                for (int j = 0; j < 8; j++)
                {
                    value += matrix[i][j] * mi[j];
                }
                value %= 2;
                multires.push_back(value);
            }

            vector<int> bdash;

            for (int i = 0; i < 8; i++)
            {
                bdash.push_back(multires[i] ^ y[i]);
            }

            reverse(bdash.begin(), bdash.end());
            int f1 = 0, f2 = 0;
            int k = 1;
            for (int i = 3; i >= 0; i--)
            {
                f1 = f1 + bdash[i] * k;
                k *= 2;
            }
            k = 1;
            for (int i = 7; i >= 4; i--)
            {
                f2 = f2 + bdash[i] * k;
                k *= 2;
            }
            string subWord = "";
            subWord += Int_To_Hexa(f1);
            subWord += Int_To_Hexa(f2);
            sdash[row][col] = subWord;
        }
    }
    return sdash;
}
void shiftRows(vector<vector<string>> &box)
{
    rotate(box[1].begin(), box[1].begin() + 1, box[1].end());
    rotate(box[2].begin(), box[2].begin() + 2, box[2].end());
    rotate(box[3].begin(), box[3].begin() + 3, box[3].end());
}
vector<string> doXor(vector<string> a, vector<string> b)
{

    vector<string> res;
    for (int i = 0; i < 4; i++)
    {
        string tmp1 = a[i], tmp2 = b[i];
        int get_1 = Hexa_To_Int(tmp1[0]) ^ Hexa_To_Int(tmp2[0]);
        int get_2 = Hexa_To_Int(tmp1[1]) ^ Hexa_To_Int(tmp2[1]);
        string ans = "";
        ans += Int_To_Hexa(get_1);
        ans += Int_To_Hexa(get_2);
        res.push_back(ans);
    }
    return res;
}
void generateSBox(vector<vector<string>> &sbox)
{

    vector<vector<int>> matrix = {
        {1, 0, 0, 0, 1, 1, 1, 1},
        {1, 1, 0, 0, 0, 1, 1, 1},
        {1, 1, 1, 0, 0, 0, 1, 1},
        {1, 1, 1, 1, 0, 0, 0, 1},
        {1, 1, 1, 1, 1, 0, 0, 0},
        {0, 1, 1, 1, 1, 1, 0, 0},
        {0, 0, 1, 1, 1, 1, 1, 0},
        {0, 0, 0, 1, 1, 1, 1, 1}};

    vector<int> y = {1, 1, 0, 0, 0, 1, 1, 0};
    for (int row = 0; row < 16; row++)
    {
        for (int col = 0; col < 16; col++)
        {
            char fs = Int_To_Hexa(row), ss = Int_To_Hexa(col);

            vector<int> firstHalf = Hex_To_Binary(fs), secondHalf = Hex_To_Binary(ss);
            vector<int> b;
            for (auto it : firstHalf)
            {
                b.push_back(it);
            }
            for (auto it : secondHalf)
            {

                b.push_back(it);
            }
            reverse(b.begin(), b.end());
            b = changepoly(b);

            vector<int> c = {1, 1, 0, 1, 1, 0, 0, 0, 1};
            vector<int> t1 = {0}, t2 = {1};
            vector<int> mi = GetInv(c, b, t1, t2);

            while (mi.size() < 8)
            {
                mi.push_back(0);
            }

            vector<int> multires;

            for (int i = 0; i < 8; i++)
            {
                int value = 0;
                for (int j = 0; j < 8; j++)
                {
                    value += matrix[i][j] * mi[j];
                }
                value %= 2;
                multires.push_back(value);
            }

            vector<int> bdash;

            for (int i = 0; i < 8; i++)
            {
                bdash.push_back(multires[i] ^ y[i]);
            }
            reverse(bdash.begin(), bdash.end());
            int f1 = 0, f2 = 0;
            int k = 1;
            for (int i = 3; i >= 0; i--)
            {
                f1 = f1 + bdash[i] * k;
                k *= 2;
            }
            k = 1;
            for (int i = 7; i >= 4; i--)
            {
                f2 = f2 + bdash[i] * k;
                k *= 2;
            }
            string subWord = "";
            subWord += Int_To_Hexa(f1);
            subWord += Int_To_Hexa(f2);
            sbox[row][col] = subWord;
        }
    }
}

void substutiteInSbox(vector<string> &s)
{
    vector<vector<int>> matrix = {
        {1, 0, 0, 0, 1, 1, 1, 1},
        {1, 1, 0, 0, 0, 1, 1, 1},
        {1, 1, 1, 0, 0, 0, 1, 1},
        {1, 1, 1, 1, 0, 0, 0, 1},
        {1, 1, 1, 1, 1, 0, 0, 0},
        {0, 1, 1, 1, 1, 1, 0, 0},
        {0, 0, 1, 1, 1, 1, 1, 0},
        {0, 0, 0, 1, 1, 1, 1, 1}};
    vector<int> y = {1, 1, 0, 0, 0, 1, 1, 0};
    vector<char> words[4];
    for (int i = 0; i < 4; i++)
    {
        words[i].push_back(s[i][0]);
        words[i].push_back(s[i][1]);
    }
    int ind = 0;
    for (int i = 0; i < 8; i += 2)
    {
        vector<int> firstHalf = Hex_To_Binary(words[ind][0]), secondHalf = Hex_To_Binary(words[ind + 1][1]);
        vector<int> b;
        for (auto it : firstHalf)
        {
            b.push_back(it);
        }
        for (auto it : secondHalf)
        {
            b.push_back(it);
        }
        reverse(b.begin(), b.end());
        b = changepoly(b);
        vector<int> c = {1, 1, 0, 1, 1, 0, 0, 0, 1};
        vector<int> t1 = {0}, t2 = {1};
        vector<int> mi = GetInv(c, b, t1, t2);
        while (mi.size() < 8)
        {
            mi.push_back(0);
        }
        vector<int> multires;
        for (int i = 0; i < 8; i++)
        {
            int value = 0;
            for (int j = 0; j < 8; j++)
            {
                value += matrix[i][j] * mi[j];
            }
            value %= 2;
            multires.push_back(value);
        }
        vector<int> bdash;
        for (int i = 0; i < 8; i++)
        {
            bdash.push_back(multires[i] ^ y[i]);
        }
        reverse(bdash.begin(), bdash.end());
        int f1 = 0, f2 = 0;
        int k = 1;
        for (int i = 3; i >= 0; i--)
        {
            f1 = f1 + bdash[i] * k;
            k *= 2;
        }
        k = 1;
        for (int i = 7; i >= 4; i--)
        {
            f2 = f2 + bdash[i] * k;
            k *= 2;
        }
        string subWord = "";
        subWord += Int_To_Hexa(f1);
        subWord += Int_To_Hexa(f2);
        s[ind] = subWord;
        ind++;
    }
}
void substitueSbox(vector<vector<string>> sbox, vector<vector<string>> &state)
{
    for (int row = 0; row < 4; row++)
    {
        for (int col = 0; col < 4; col++)
        {
            string tmp = state[row][col];
            int currow = Hexa_To_Int(tmp[0]), curcol = Hexa_To_Int(tmp[1]);
            state[row][col] = sbox[currow][curcol];
        }
    }
}
void subWord(vector<string> &word, vector<vector<string>> sbox)
{
    for (int i = 0; i < 4; i++)
    {
        char a = word[i][0], b = word[i][1];
        int row = Hexa_To_Int(a), col = Hexa_To_Int(b);
        string tmpSub = sbox[row][col];
        word[i] = tmpSub;
    }
}
void printVector(vector<string> a)
{
    cout << endl;
    for (auto it : a)
        cout << it << " ";
    cout << endl;
}
vector<vector<string>> keyExpansion(vector<vector<string>> key, vector<vector<string>> sbox)
{
    vector<vector<string>> w(44);
    map<int, vector<char>> rc;
    rc.insert({1, {'0', '1', '0', '0', '0', '0', '0', '0'}});
    rc.insert({2, {'0', '2', '0', '0', '0', '0', '0', '0'}});
    rc.insert({3, {'0', '4', '0', '0', '0', '0', '0', '0'}});
    rc.insert({4, {'0', '8', '0', '0', '0', '0', '0', '0'}});
    rc.insert({5, {'1', '0', '0', '0', '0', '0', '0', '0'}});
    rc.insert({6, {'2', '0', '0', '0', '0', '0', '0', '0'}});
    rc.insert({7, {'4', '0', '0', '0', '0', '0', '0', '0'}});
    rc.insert({8, {'8', '0', '0', '0', '0', '0', '0', '0'}});
    rc.insert({9, {'1', 'b', '0', '0', '0', '0', '0', '0'}});
    rc.insert({10, {'3', '6', '0', '0', '0', '0', '0', '0'}});
    w[0] = key[0];
    w[1] = key[1];
    w[2] = key[2];
    w[3] = key[3];

    vector<vector<string>> Round_Keys;
    Round_Keys.push_back(w[0]);
    Round_Keys.push_back(w[1]);
    Round_Keys.push_back(w[2]);
    Round_Keys.push_back(w[3]);
    for (int i = 4; i < 44; i++)
    {
        if (i % 4 == 0)
        {
            vector<string> wordi_1 = w[i - 1];
            string curWord = wordi_1[0];
            rotate(wordi_1.begin(), wordi_1.begin() + 1, wordi_1.end());
            subWord(wordi_1, sbox);

            int rnd = i / 4;
            vector<char> rc_round = rc[rnd];
            vector<string> rcDash;
            for (int k = 0; k < 8; k += 2)
            {
                string curWord = "";
                curWord += rc_round[k];
                curWord += rc_round[k + 1];
                rcDash.push_back(curWord);
            }
            vector<string> t = doXor(wordi_1, rcDash);
            w[i] = doXor(t, w[i - 4]);
        }
        else
        {
            w[i] = doXor(w[i - 1], w[i - 4]);
        }
        Round_Keys.push_back(w[i]);
    }
    return Round_Keys;
}
vector<int> addPolynomial(vector<int> a, vector<int> b)
{
    vector<int> res;
    while (a.size() < 8)
        a.push_back(0);
    while (b.size() < 8)
        b.push_back(0);
    for (int i = 0; i < 8; i++)
    {
        int val = (a[i] + b[i]) % 2;
        res.push_back(val);
    }
    return res;
}
string multiMatrix(string a, string b)
{
    vector<int> tmp1_0 = Hex_To_Binary(a[0]), tmp1_1 = Hex_To_Binary(a[1]);
    vector<int> tmp2_0 = Hex_To_Binary(b[0]), tmp2_1 = Hex_To_Binary(b[1]);
    vector<int> aPoly, bPoly;
    for (auto it : tmp1_0)
        aPoly.push_back(it);
    for (auto it : tmp1_1)
        aPoly.push_back(it);
    for (auto it : tmp2_0)
        bPoly.push_back(it);
    for (auto it : tmp2_1)
        bPoly.push_back(it);
    reverse(aPoly.begin(), aPoly.end());
    reverse(bPoly.begin(), bPoly.end());
    applyMod2(aPoly);
    if (aPoly.size() == 0)
        aPoly.push_back(0);
    applyMod2(bPoly);
    if (bPoly.size() == 0)
        bPoly.push_back(0);
    vector<int> tmpk = {1, 1, 0, 1, 1, 0, 0, 0, 1};
    vector<int> ans = Mul_Pol(aPoly, bPoly);
    applyMod2(ans);
    if (ans.size() > 8)
    {
        vector<vector<int>> zk = Div_Pol(ans, tmpk);
        ans = zk[1];
    }
    applyMod2(ans);
    if (ans.size() == 0)
        return "00";
    while (ans.size() < 8)
        ans.push_back(0);
    int val1 = 0, k = 1;
    for (int i = 0; i < 4; i++)
    {
        val1 += ans[i] * k;
        k *= 2;
    }
    int val2 = 0;
    k = 1;
    for (int i = 4; i < 8; i++)
    {
        val2 += ans[i] * k;
        k *= 2;
    }
    string res = "";
    res += Int_To_Hexa(val2);
    res += Int_To_Hexa(val1);
    return res;
}
string addMatrix(string a, string b)
{
    if (a == "00")
        return b;
    if (b == "00")
        return a;
    vector<int> tmp1_0 = Hex_To_Binary(a[0]), tmp1_1 = Hex_To_Binary(a[1]);
    vector<int> tmp2_0 = Hex_To_Binary(b[0]), tmp2_1 = Hex_To_Binary(b[1]);
    vector<int> aPoly, bPoly;
    for (auto it : tmp1_0)
        aPoly.push_back(it);
    for (auto it : tmp1_1)
        aPoly.push_back(it);
    for (auto it : tmp2_0)
        bPoly.push_back(it);
    for (auto it : tmp2_1)
        bPoly.push_back(it);
    reverse(aPoly.begin(), aPoly.end());
    reverse(bPoly.begin(), bPoly.end());
    applyMod2(aPoly);
    if (aPoly.size() == 0)
        aPoly.push_back(0);
    applyMod2(bPoly);
    if (bPoly.size() == 0)
        bPoly.push_back(0);
    vector<int> ans = addPolynomial(aPoly, bPoly);
    if (ans.size() == 0)
        return "00";
    while (ans.size() < 8)
        ans.push_back(0);
    int val1 = 0, k = 1;
    for (int i = 0; i < 4; i++)
    {
        val1 += ans[i] * k;
        k *= 2;
    }
    int val2 = 0;
    k = 1;
    for (int i = 4; i < 8; i++)
    {
        val2 += ans[i] * k;
        k *= 2;
    }
    string res = "";
    res += Int_To_Hexa(val2);
    res += Int_To_Hexa(val1);
    return res;
}
vector<vector<string>> mixColumns(vector<vector<string>> state)
{
    vector<vector<string>> constantMatrix = {
        {"02", "03", "01", "01"},
        {"01", "02", "03", "01"},
        {"01", "01", "02", "03"},
        {"03", "01", "01", "02"}};
    vector<vector<string>> res(4, vector<string>(4, "00"));
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            for (int k = 0; k < 4; k++)
            {
                vector<int> tmpk = {1, 1, 0, 1, 0, 0, 0, 1};
                string multitemp = multiMatrix(constantMatrix[i][k], state[k][j]);
                res[i][j] = addMatrix(multitemp, res[i][j]);
            }
        }
    }
    return res;
}
vector<vector<string>> MatrixXor(vector<vector<string>> a, vector<vector<string>> b)
{
    vector<vector<string>> res;
    for (int i = 0; i < 4; i++)
    {
        vector<string> tmp = doXor(a[i], b[i]);
        res.push_back(tmp);
    }
    return res;
}
vector<vector<string>> getRoundKey(vector<vector<string>> Round_Keys, int ind)
{
    vector<vector<string>> tmpKeys;
    vector<vector<string>> res(4, vector<string>(4, ""));
    tmpKeys.push_back(Round_Keys[ind]);
    tmpKeys.push_back(Round_Keys[ind + 1]);
    tmpKeys.push_back(Round_Keys[ind + 2]);
    tmpKeys.push_back(Round_Keys[ind + 3]);
    for (int row = 0; row < 4; row++)
    {
        for (int col = 0; col < 4; col++)
        {
            res[col][row] = tmpKeys[row][col];
        }
    }
    return res;
}
void printMatrix(vector<vector<string>> a)
{
    cout << endl;
    for (int row = 0; row < 4; row++)
    {
        for (int col = 0; col < 4; col++)
        {
            cout << a[row][col] << " ";
        }
        cout << endl;
    }
    cout << endl;
}

void get_word_Mat(string s, vector<vector<string>> &words, vector<vector<string>> &key, string k)
{
    int ind = 0;
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            string tmp = "";
            string tmpWord = "";
            tmpWord += s[ind];
            tmpWord += s[ind + 1];
            words[j][i] = tmpWord;
            tmp += k[ind];
            tmp += k[ind + 1];
            key[i][j] = tmp;
            ind += 2;
        }
    }
}

string aes(vector<vector<string>> sbox, vector<vector<string>> word, vector<vector<string>> Round_Keys)
{
    int round = 0;
    int windex = 0;
    vector<vector<string>> curKey = getRoundKey(Round_Keys, windex);
    windex += 4;
    int ri = 1;
    vector<vector<string>> statecur = MatrixXor(word, curKey);
    for (int rnd = 0; rnd < 9; rnd++)
    {
        substitueSbox(sbox, statecur);
        shiftRows(statecur);
        statecur = mixColumns(statecur);
        curKey = getRoundKey(Round_Keys, windex);
        windex += 4;
        ri++;
        statecur = MatrixXor(statecur, curKey);
    }

    substitueSbox(sbox, statecur);
    shiftRows(statecur);
    curKey = getRoundKey(Round_Keys, windex);
    statecur = MatrixXor(statecur, curKey);
    string ciphertext = "";
    for (auto it : statecur)
    {
        for (string i : it)
        {
            ciphertext += i;
        }
    }
    return ciphertext;
}

string AES_Encryption(string s, string k)
{
    s = BinToHexa(s);
    k = BinToHexa(k);
    vector<vector<string>> sbox(16, vector<string>(16, ""));
    generateSBox(sbox);
    vector<vector<string>> words(4, vector<string>(4, ""));
    vector<vector<string>> key(4, vector<string>(4, ""));
    get_word_Mat(s, words, key, k);
    vector<vector<string>> Round_Keys = keyExpansion(key, sbox);
    return HexaToBin(aes(sbox, words, Round_Keys));
}

#endif