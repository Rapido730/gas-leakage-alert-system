#include <bits/stdc++.h>
#include "aes_encryption.hpp"
using namespace std;

string getHexaMsg()
{

    int n = rand() % 1000 + 500;
    string s = "";

    while (n--)
    {
        int temp = rand() % 16;

        if (temp < 10)
        {
            s.push_back('0' + temp);
        }
        else
        {
            s.push_back('a' + temp - 10);
        }
    }
    return s;
}

string InitialVector()
{
    int n = 128;
    string s = "";

    while (n--)
    {
        int temp = rand() % 2;

        s.push_back('0' + temp);
    }
    return s;
}

string getBinMsg()
{

    int n = rand() % 500 + 200;
    string s = "";

    while (n--)
    {
        int temp = rand() % 2;

        s.push_back('0' + temp);
    }
    return s;
}

string padding(string msg)
{

    int len = msg.length();

    len = len % 128;
    if (len != 0)
    {
        len = 128 - len;
        msg = msg + "1";
        len--;
        while (len--)
        {
            msg += "0";
        }
    }
    return msg;
}

string compression(string H, string msg_block)
{
    string ciphertext = AES_Encryption(msg_block, H);
    string H_next = xor_op(ciphertext, H);
    return H_next;
}

string hashing(string msg)
{
    int block_size = 128;
    int round = msg.size() / block_size;
    int i = 0;
    string m = msg.substr(0, block_size);
    string iv = InitialVector();
    cout << "\ninitial vector = " << iv << endl;
    string H = iv;
    while (i < round)
    {
        string msg_block = msg.substr(i * 128, 128);
        string H_next = compression(H, msg_block);
        H = H_next;
        i++;
    }

    return H;
}

int main()
{
    srand(time(0));
    string msg = getBinMsg();
    cout << "\nplaintext = " << msg << endl;

    string msg1 = padding(msg);
    cout << "\nafter padding = " << msg1 << endl;
    string Message_disgest = hashing(msg1);
    cout
        << "\nMessage disgest = " << Message_disgest << endl;
}