#include <bits/stdc++.h>

using namespace std;

bool E(string s, int &ind), F(string s, int &ind), E_dash(string s, int &ind), T(string s, int &ind), T_dash(string s, int &ind);

bool T_dash(string s, int &ind)
{
    cout << "T1\n";
    if (s[ind] == '*')
    {
        ind++;
        if (F(s, ind))
        {
            ind++;
            return T_dash(s, ind);
        }
        else
        {
            return false;
        }
    }
    else
    {
        return true;
    }
}

bool F(string s, int &ind)
{
    cout << "F\n";
    if (s[ind] == '(')
    {
        ind++;
        if (E(s, ind))
        {

            if (s[ind] == ')')
            {
                ind++;
                return 1;
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return 0;
        }
    }
    else if (s[ind] >= 'a' && s[ind] <= 'z')
    {
        ind++;
        return 1;
    }

    return 0;
}

bool T(string s, int &ind)
{
    cout << "T\n";
    if (F(s, ind))
    {
        return T_dash(s, ind);
    }

    return 0;
}

bool E_dash(string s, int &ind)
{
    cout << "E1\n";
    if (s[ind] == '+')
    {
        ind++;
        if (T(s, ind))
        {

            if (E_dash(s, ind))
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return 0;
        }
    }

    return 1;

    // e
}

bool E(string s, int &ind)
{
    cout << "E\n";
    if (T(s, ind))
    {

        if (E_dash(s, ind))
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }

    return 0;
}

int main()
{
    string s;
    cout << "Enter string : ";
    cin >> s;
    int ind = 0;
    if (E(s, ind))
    {
        cout << "\nyes";
    }
    cout << "\n"
         << ind << endl;
}