
#include <bits/stdc++.h>
using namespace std;

unordered_map<char, vector<string>> gram;

unordered_map<char, set<char>> leading;

unordered_map<char, set<char>> trailing;

vector<string> extract_produc(string p)
{

    int ind = 0;
    vector<string> prod;
    string temp = "";
    while (ind < p.length())
    {
        if (p[ind] == '|')
        {
            prod.push_back(temp);
            temp = "";
        }
        else if (ind == p.length() - 1)
        {
            temp.push_back(p[ind]);
            prod.push_back(temp);
            temp = "";
        }
        else
        {
            temp.push_back(p[ind]);
        }
        ind++;
    }

    return prod;
}

set<char> leading_ext(char V)
{

    set<char> s;
    for (auto it : gram[V])
    {

        if (it[0] >= 'a' && it[0] <= 'z')
        {
            s.insert(it[0]);
        }
        else if (it[0] >= 'A' && it[0] <= 'Z')
        {
            set<char> temp;
            if (leading.find(it[0]) != leading.end())
            {
                temp = leading[it[0]];
            }
            else
            {
                temp = leading_ext(it[0]);
            }

            if (it[1] >= 'a' && it[1] <= 'z')
            {
                s.insert(it[1]);
            }

            for (auto i : temp)
            {
                s.insert(i);
            }
        }
    }

    return leading[V] = s;
}

set<char> trailing_ext(char V)
{

    set<char> s;
    for (auto it : gram[V])
    {
        int l = it.length();
        cout << it << endl;

        if (it[l - 1] >= 'a' && it[l - 1] <= 'z')
        {
            s.insert(it[l - 1]);
        }
        else if (it[l - 1] >= 'A' && it[l - 1] <= 'Z')
        {
            set<char> temp;
            if (it[l - 1] != V)
                if (trailing.find(it[l - 1]) != trailing.end())
                {
                    temp = trailing[it[l - 1]];
                }
                else
                {
                    temp = trailing_ext(it[l - 1]);
                }

            if (l - 2 >= 0)
                if (it[l - 2] >= 'a' && it[l - 2] <= 'z')
                {
                    s.insert(it[l - 2]);
                }

            for (auto i : temp)
            {
                s.insert(i);
            }
        }
    }

    return trailing[V] = s;
}

int main()
{

    int n;
    cout << "number of productions : ";
    cin >> n;

    char S;

    for (int i = 0; i < n; i++)
    {
        string temp;
        cin >> temp;

        char V = temp[0];

        temp = temp.substr(2);

        gram[V] = extract_produc(temp);
    }

    for (auto it : gram)
    {

        cout << it.first << " = ";
        leading_ext(it.first);
        trailing_ext(it.first);

        for (auto i : it.second)
        {
            cout << i << " | ";
        }

        cout << endl;
    }

    cout << "\n\n";
    for (auto it : leading)
    {

        cout << it.first << " = ";

        for (auto i : it.second)
        {
            cout << i << " , ";
        }

        cout << endl;
    }

    cout << "\n\n";
    for (auto it : trailing)
    {

        cout << it.first << " = ";

        for (auto i : it.second)
        {
            cout << i << " , ";
        }

        cout << endl;
    }
}