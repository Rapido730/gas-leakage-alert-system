// input and output template
// 5
// E TA

// A +TA|^

// T FB

// B *FB|^

// F (E)|i

// First(E) = { (, i, }          // output
// First(A) = { +, ^, }
// First(T) = { (, i, }
// First(B) = { *, ^, }
// First(F) = { (, i, }

// Follow(E) = { $, ), }
// Follow(A) = { $, ), }
// Follow(T) = { $, ), +, }
// Follow(B) = { $, ), +, }
// Follow(F) = { $, ), *, +, }

#include <bits/stdc++.h>
using namespace std;

unordered_map<char, vector<string>> gram;   // to store production rules
unordered_map<char, vector<char>> firstSet; // to store first of all Non-Terminals
unordered_map<char, set<char>> followSet;   //  to store follow of all Non-Terminals

vector<char> extractTerminals() // function to find all distint terminals.
{

    set<char> terminals;

    for (auto it : gram)
    {
        for (string s : it.second)
        {
            for (char c : s)
            {
                if (!(c >= 'A' && c <= 'Z'))
                    terminals.insert(c);
            }
        }
    }

    vector<char> ans;
    for (char c : terminals)
    {
        ans.push_back(c);
    }

    return ans;
}

vector<string> expSplitter(string exp) // function to extract all production rules
{
    int ind = 0;
    string s = "";
    vector<string> ans;

    while (ind <= exp.size())
    {
        if (ind == exp.size() || exp[ind] == '|')
        {
            ans.push_back(s);
            s = "";
        }
        else
        {
            s.push_back(exp[ind]);
        }
        ind++;
    }

    return ans;
}

vector<char> first(char V) // function to find first
{
    vector<char> firstSet;
    for (auto it : gram[V])
    {
        int ind = 0;
        bool flag = false;
        while (ind < it.size() && (!flag))
        {
            flag = true;
            if (it[ind] >= 'A' && it[ind] <= 'Z')
            {
                vector<char> temp;
                temp = first(it[ind]);
                for (char c : temp)
                {
                    if (c == '^')
                    {
                        flag = false;
                    }
                    firstSet.push_back(c);
                }
            }
            else if (it[ind] == '^')
            {
                firstSet.push_back(it[ind]);
                ind++;
                flag = false;
            }
            else
            {
                firstSet.push_back(it[ind]);
            }
            ind++;
        }
    }

    return firstSet;
}

set<char> follow(char V) // function to find follow
{
    set<char> followCurSet;

    for (auto it : gram)
    {
        for (string s : it.second)
        {
            for (int c = 0; c < s.size(); c++)
            {
                // cout<<c<<endl;
                if (s[c] == V)
                {

                    bool flag = false;
                    int ind = c;
                    while (ind < s.size() && (!flag))
                    {
                        flag = true;
                        if (ind == s.size() - 1)
                        {
                            if (it.first != s[ind])
                            {

                                set<char> temp;
                                if (followSet[it.first].size() == 0)
                                {
                                    temp = follow(it.first);
                                }
                                else
                                {
                                    temp = followSet[it.first];
                                }
                                for (char fi : temp)
                                {
                                    followCurSet.insert(fi);
                                }
                            }
                        }
                        else
                        {
                            if (s[ind + 1] >= 'A' && s[ind + 1] <= 'Z')
                            {
                                for (char C : firstSet[s[ind + 1]])
                                {
                                    if (C == '^')
                                    {
                                        flag = false;
                                    }
                                    else
                                    {

                                        followCurSet.insert(C);
                                    }
                                }
                            }
                            else
                            {
                                followCurSet.insert(s[ind + 1]);
                            }
                        }
                        ind++;
                    }
                }
            }
        }
    }
    return followSet[V] = followCurSet;
}

int main()
{
    int n;
    cin >> n;

    vector<char> variables;
    vector<char> terminals;
    char S = 'S';

    for (int i = 0; i < n; i++)
    {
        char V;
        cin >> V;
        if (i == 0)
        {
            S = V;
        }
        variables.push_back(V);
        string exp;
        cin >> exp;

        vector<string> ans;
        ans = expSplitter(exp);

        gram[V] = ans;
    }

    terminals = extractTerminals();

    vector<vector<string>> ll1(variables.size(), vector<string>(terminals.size() + 1));

    cout << "\n\n";
    for (char V : variables)
    {
        vector<char> temp = first(V);
        firstSet[V] = temp;
    }
    for (char V : variables)
    {
        printf("First(%c) = { ", V);
        for (char c : firstSet[V])
        {
            cout << c << ", ";
        }
        cout << "} " << endl;
    }
    cout << "\n\n";
    follow(S);
    followSet[S].insert('$');

    for (char V : variables)
    {
        if (V == S)
            continue;
        follow(V);
    }

    for (char V : variables)
    {

        printf("Follow(%c) = { ", V);
        for (char c : followSet[V])
        {
            cout << c << ", ";
        }
        cout << "} " << endl;
    }

    return 0;
}
