// input and output template
// 5
// E TP
// P +TP|^
// T FQ
// Q *FQ|^
// F (E)|a


// First(F) = { (, a, } 
// First(Q) = { *, ^, } 
// First(T) = { (, a, } 
// First(P) = { +, ^, } 
// First(E) = { (, a, } 


// Follow(F) = { $, ), *, +, } 
// Follow(Q) = { $, ), +, } 
// Follow(T) = { $, ), +, } 
// Follow(P) = { $, ), } 
// Follow(E) = { $, ), } 


//          $           (           )           *           +           a                       
// E                 E -> TP                                      E -> TP     
// P      P -> ^                P -> ^                P -> +TP                
// T                 T -> FQ                                      T -> FQ     
// Q      Q -> ^                Q -> ^     Q -> *FQ     Q -> ^                
// F                 F -> (E)                                      F -> a

#include <bits/stdc++.h>
using namespace std;
unordered_map<char, vector<string>> gram;   // to store production rules
unordered_map<char, vector<char>> firstSet; // to store first of all Non-Terminals
unordered_map<char, set<char>> followSet;   //  to store follow of all Non-Terminals

void extractTerminals(int &t, unordered_map<char, int> &terminalsMap) // to find all distict Terminals.
{

    set<char> terminals;

    for (auto it : gram)
    {
        for (string s : it.second)
        {
            for (char c : s)
            {
                if (!(c >= 'A' && c <= 'Z'))
                    terminals.insert(c);
            }
        }
    }

    for (char c : terminals)
    {
        if (c != '^')
            terminalsMap[c] = t++;
    }
}

char getTerminal(unordered_map<char, int> &terminals, int ind) // utlity function to find a specific terminal
{
    for (auto it : terminals)
    {
        if (it.second == ind)
            return it.first;
    }
    return ' ';
}

char getVariable(unordered_map<char, int> &variables, int ind) // utlity function to find a specific Non-Terminal
{
    for (auto it : variables)
    {
        if (it.second == ind)
            return it.first;
    }
    return ' ';
}

void parsingLL1(vector<vector<string>> &ll1, unordered_map<char, int> &terminals, unordered_map<char, int> &variables) // function to generate ll(1) parsing table
{
    for (auto it : gram)
    {
        char V = it.first;
        for (string s : it.second)
        {
            string exp(1, V);
            exp += " -> " + s;

            if (s[0] >= 'A' && s[0] <= 'Z')
            {
                bool flag = false;
                int ind = 0;

                while (ind <= s.size() && (!flag))
                {
                    flag = true;
                    if (ind == s.size())
                    {
                        for (char c : followSet[V])
                        {
                            ll1[variables[V]][terminals[c]] = exp;
                        }
                    }
                    else
                    {

                        for (char c : firstSet[s[ind]])
                        {
                            if (c == '^')
                            {
                                flag = false;
                            }
                            else
                            {
                                ll1[variables[V]][terminals[c]] = exp;
                            }
                        }
                        ind++;
                    }
                }
            }
            else
            {
                if (s[0] == '^')
                {
                    for (char c : followSet[V])
                    {
                        ll1[variables[V]][terminals[c]] = exp;
                    }
                }
                else
                    ll1[variables[V]][terminals[s[0]]] = exp;
            }
        }
    }
}

vector<string> expSplitter(string exp) // to extract all production rules
{
    int ind = 0;
    string s = "";
    vector<string> ans;

    while (ind <= exp.size())
    {
        if (ind == exp.size() || exp[ind] == '|')
        {
            ans.push_back(s);
            s = "";
        }
        else
        {
            s.push_back(exp[ind]);
        }
        ind++;
    }

    return ans;
}

vector<char> first(char V) // to find first of Non-terminals
{
    vector<char> firstSet;
    for (auto it : gram[V])
    {
        int ind = 0;
        bool flag = false;
        while (ind < it.size() && (!flag))
        {
            flag = true;
            if (it[ind] >= 'A' && it[ind] <= 'Z')
            {
                vector<char> temp;
                temp = first(it[ind]);
                for (char c : temp)
                {
                    if (c == '^')
                    {
                        flag = false;
                    }
                    firstSet.push_back(c);
                }
            }
            else if (it[ind] == '^')
            {
                firstSet.push_back(it[ind]);
                ind++;
                flag = false;
            }
            else
            {
                firstSet.push_back(it[ind]);
            }
            ind++;
        }
    }

    return firstSet;
}

set<char> follow(char V) // to find follow of Non-Terminals
{
    set<char> followCurSet;

    for (auto it : gram)
    {
        for (string s : it.second)
        {
            for (int c = 0; c < s.size(); c++)
            {
                // cout<<c<<endl;
                if (s[c] == V)
                {

                    bool flag = false;
                    int ind = c;
                    while (ind < s.size() && (!flag))
                    {
                        flag = true;
                        if (ind == s.size() - 1)
                        {
                            if (it.first != s[ind])
                            {

                                set<char> temp;
                                if (followSet[it.first].size() == 0)
                                {
                                    temp = follow(it.first);
                                }
                                else
                                {
                                    temp = followSet[it.first];
                                }
                                for (char fi : temp)
                                {
                                    followCurSet.insert(fi);
                                }
                            }
                        }
                        else
                        {
                            if (s[ind + 1] >= 'A' && s[ind + 1] <= 'Z')
                            {
                                for (char C : firstSet[s[ind + 1]])
                                {
                                    if (C == '^')
                                    {
                                        flag = false;
                                    }
                                    else
                                    {

                                        followCurSet.insert(C);
                                    }
                                }
                            }
                            else
                            {
                                followCurSet.insert(s[ind + 1]);
                            }
                        }
                        ind++;
                    }
                }
            }
        }
    }
    return followSet[V] = followCurSet;
}

int main()
{
    int n;
    cin >> n;

    unordered_map<char, int> variables;
    unordered_map<char, int> terminals;
    int t = 0;
    int v = 0;
    terminals['$'] = t++;
    char S = 'E';

    for (int i = 0; i < n; i++)
    {
        char V;
        cin >> V;
        variables[V] = v++;
        if (i == 0)
        {
            S = V;
        }
        string exp;
        cin >> exp;

        vector<string> ans;
        ans = expSplitter(exp);

        gram[V] = ans;
    }

    extractTerminals(t, terminals);

    vector<vector<string>> ll1(variables.size(), vector<string>(terminals.size(), "      "));

    cout << "\n\n";
    for (auto it : variables)
    {
        char V = it.first;
        vector<char> temp = first(V);
        firstSet[V] = temp;
    }
    for (auto it : variables)
    {
        char V = it.first;
        printf("First(%c) = { ", V);
        for (char c : firstSet[V])
        {
            cout << c << ", ";
        }
        cout << "} " << endl;
    }
    cout << "\n\n";
    follow(S);
    followSet[S].insert('$');

    for (auto it : variables)
    {
        char V = it.first;
        if (V == S)
            continue;
        follow(V);
    }

    for (auto it : variables)
    {
        char V = it.first;
        printf("Follow(%c) = { ", V);
        for (char c : followSet[V])
        {
            cout << c << ", ";
        }
        cout << "} " << endl;
    }

    cout << "\n\n";
    parsingLL1(ll1, terminals, variables);
    int j = 0;
    int i = 0;
    cout << "         ";
    for (; j <= t; j++)
    {
        cout << getTerminal(terminals, j) << "           ";
    }
    cout << endl;
    for (auto it : ll1)
    {
        cout << getVariable(variables, i++) << "      ";
        for (string s : it)
        {
            cout << s << "     ";
        }
        cout << endl;
    }

    return 0;
}


// E TP
// P +TP|^
// T FQ
// Q *FQ|^
// F (E)|a

