#include <bits/stdc++.h>
using namespace std;

ifstream fin;

unordered_map<char, int> separators;
unordered_map<string, int> keyword;
unordered_map<string, int> operators;

int keywords_c = 0, identifier_c = 0, operators_c = 0, separators_c = 0, constant_c;

void prepare()
{
    separators[';'] = 1;
    separators[','] = 1;
    separators['('] = 1;
    separators[')'] = 1;
    separators['{'] = 1;
    separators['}'] = 1;
    // separators['<'] = 1;
    // separators['>'] = 1;
    separators['.'] = 1;
    separators['['] = 1;
    separators[']'] = 1;

    operators["<<"] = 1;
    operators[">>"] = 1;
    operators["++"] = 1;
    operators["--"] = 1;
    operators["="] = 1;
    operators["=="] = 1;

    keyword["auto"] = 1;
    keyword["double"] = 1;
    keyword["int"] = 1;
    keyword["struct"] = 1;
    keyword["break"] = 1;
    keyword["else"] = 1;
    keyword["long"] = 1;
    keyword["switch"] = 1;
    keyword["case"] = 1;
    keyword["enum"] = 1;
    keyword["register"] = 1;
    keyword["typedef"] = 1;
    keyword["char"] = 1;
    keyword["extern"] = 1;
    keyword["return"] = 1;
    keyword["union"] = 1;
    keyword["const"] = 1;
    keyword["float"] = 1;
    keyword["short"] = 1;
    keyword["unsigned"] = 1;
    keyword["continue"] = 1;
    keyword["for"] = 1;
    keyword["signed"] = 1;
    keyword["void"] = 1;
    keyword["default"] = 1;
    keyword["goto"] = 1;
    keyword["sizeof"] = 1;
    keyword["volatile"] = 1;
    keyword["do"] = 1;
    keyword["if"] = 1;
    keyword["static"] = 1;
    keyword["while"] = 1;
    keyword["endl"] = 1;
    keyword["cout"] = 1;
    keyword["cin"] = 1;
    keyword["main"] = 1;
}

bool isIndentifier(string str)
{
    if (str[0] >= '0' && str[0] <= '9')
    {
        return false;
    }
    else if (str[0] == '_')
        return true;
    else if (str[0] >= 'a' && str[0] <= 'z')
    {
        return true;
    }
    else if (str[0] >= 'A' && str[0] <= 'Z')
    {
        return true;
    }
    return false;
}

void increaseCount(string str)
{
    if (keyword.find(str) != keyword.end())
    {
        cout << "keyword\n";
        keywords_c++;
    }
    else if (operators.find(str) != operators.end())
    {
        cout << "operator\n";
        operators_c++;
    }
    else if (isIndentifier(str))
    {
        cout << "identifier\n";
        identifier_c++;
    }
    else
    {
        cout << "constant\n";
        constant_c++;
    }
}

int lineAnalyzer(string line)
{
    int size = line.size();
    // cout << size << endl;
    // cout << "\n"
    //      << line << endl;
    int i = 0;
    while (line[i] == ' ')
        i++;

    if (line[i] == '/' && line[i + 1] == '/')
        return 0;
    int count = 0;
    string temp = "";

    for (int i = 0; i < size; i++)
    {
        if (line[i] == ' ')
        {
            if (temp.size() > 0)
            {
                cout << "\"" << temp << "\"   ";
                increaseCount(temp);
            }
            temp = "";
        }
        else if (separators.find(line[i]) != separators.end())
        {
            if (temp.size() > 0)
            {
                cout << "\"" << temp << "\"   ";
                increaseCount(temp);
                count++;
            }
            // count++;
            separators_c++;
            cout << "\"" << line[i] << "\"   ";
            temp = "";
        }
        else if (i == line.size() - 1)
        {
            temp.push_back(line[i]);
            if (temp.size() > 0)
            {
                cout << "\"" << temp << "\"   ";
                increaseCount(temp);
                // count++;
            }
        }
        else
        {
            temp.push_back(line[i]);
        }
    }

    return count;
}

int main()
{
    fin.open("helllo.cpp");
    prepare();
    while (!fin.eof())
    {

        string s;
        char arr[1000];
        fin.getline(arr, 1000);
        s = arr;
        // cout <<
        lineAnalyzer(arr);
        cout << endl;

        // << endl
        //      << endl;
    }

    cout << "\nkeywords count = " << keywords_c << "\n";
    cout << "separators count = " << separators_c << "\n";
    cout << "identifier count = " << identifier_c << "\n";
    cout << "constant count = " << constant_c << "\n";
    cout << "operators count  = " << operators_c << endl;
    cout << "Token count = " << (keywords_c + separators_c + identifier_c + constant_c + operators_c) << endl;
    return 0;
}