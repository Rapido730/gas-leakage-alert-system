#include<bits/stdc++.h>
using namespace std;
ofstream fout;
int count = 0;
void splitter(string str){
    vector<string> v;
    string temp = "";
    for(int i=0;i<str.size();i++){
        if(str[i]==' '){
            if(temp.size()>0){
                v.push_back(temp);
            }
            temp="";
        }
        else if(i==str.size()-1){
            temp.push_back(str[i]);
            if(temp.size()>0){
                v.push_back(temp);
            }
            temp="";
        }
        else{
            temp.push_back(str[i]);
        }
    }

    for(string s:v){
        cout<<s<<endl;
        // cout<<(++::count)<<endl;
        string res = "keyword[\""+s+"\""+"]=1;\n";
        fout<<res<<endl;
    }

}

int main(){
    ifstream fin;
    fin.open("file.txt");
    fout.open("output.txt");
    while(!fin.eof()){
        char arr[1000];
        string str;
        fin.getline(arr,1000);
        str = arr;
        splitter(str);
    }

    return 0;
}