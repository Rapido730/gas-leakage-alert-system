#ifndef SIGN_IN_HPP // to prevent redefination functions
#define SIGN_IN_HPP

// sign in function

// necessary header files
#include <bits/stdc++.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "comp_rece.hpp"
#include "md5.h"
#include "html_invoice.hpp"
#include "validation.hpp"

using namespace std;


vector<string> editProfile(string user, int client_id)
{
    // file stream to manage csv
    fstream fin, fout, finn;

    fin.open("data/sampleFile.csv", ios::in);

    vector<string> row, final;
    string line, word;
    string x = "10";

    compose(client_id, "\n\n***** Customer has the Liberty to modifiy his details whenever he wants *****\n\n0");
    compose(client_id, "\n\nWhat do you wish to edit: \n\n0");

    while (!fin.eof())
    {
        row.clear();

        getline(fin, line);

        stringstream s(line);

        while (getline(s, word, ','))
        {
            row.push_back(word);
        }

        string userid = row[0];
        int n = row.size();

        if (user == userid)
        {
            vector<string> row1;
            string line1, word1;
            while (1)
            {
                compose(client_id, "\n0.Go Back, 1.User_ID, 2.Password, 3.Name, 4.Age:  \n 1");
                x = receive(client_id);

                if (x == "0")
                {
                    cout << endl;
                    break;
                }
                else if (x == "1")
                {
                    finn.open("data/sampleFile.csv", ios::in);
                    string newID;
                    while (1)
                    {
                        compose(client_id, "Enter new User ID: \n 1"); // modifying User ID
                        newID = receive(client_id);

                        int count = 0;

                        finn.seekg(0, ios::beg);

                        while (!finn.eof())
                        {
                            row1.clear();

                            getline(finn, line1);

                            stringstream s1(line1);

                            while (getline(s1, word1, ','))
                            {
                                row1.push_back(word1);
                            }

                            string userid = row1[0];

                            if (newID == userid) // checks for uniqueness
                            {
                                count = 1;
                                break;
                            }

                            if (fout.eof())
                            {
                                break;
                            }
                        }
                        if (count == 0)
                        {
                            row[0] = newID;

                            compose(client_id, "\nModified Sucessfully!\n\n0");
                            break;
                        }
                        else
                        {
                            compose(client_id, "\nUser ID already in use, choose another!\n\n0");
                        }
                    }
                    finn.close();
                }
                else if (x == "2")
                {
                    string oldPass, pass, pass1;
                    while (1)
                    {
                        compose(client_id, "Enter Current Password:  \n 1"); // modifying password
                        oldPass = receive(client_id);

                        if (md5(oldPass) == row[1])
                        {
                            while (1)
                            {
                                compose(client_id, "Enter New Password: 1");
                                pass = receive(client_id);
                                while (pass.length() < 8)
                                {
                                    compose(client_id, "Password is too short. Password length should be atleast 8.\n Try again1");
                                    pass = receive(client_id);
                                }

                                compose(client_id, "Confirm New Password: \n 1");
                                pass1 = receive(client_id);

                                if (pass == pass1)
                                {
                                    break;
                                }
                                else
                                {
                                    compose(client_id, "Type the same password again!\n\n0");
                                }
                            }
                            break;
                        }
                        else
                        {
                            compose(client_id, "\nWrong password, Try again!\n0");
                        }
                    }

                    row[1] = md5(pass);
                    compose(client_id, "\nModified Succesfully! \n\n0");
                }
                else if (x == "3")
                {
                    string newName;

                    compose(client_id, "Enter New Name: 1");
                    newName = receive(client_id);
                    while (!isChars(newName) || newName.length() > 50)
                    {
                        if (newName.length() > 50)
                        {
                            compose(client_id, "Name is too long. Kindly Enter valid Name : 1");
                            newName = receive(client_id);
                        }
                        else
                        {
                            compose(client_id, "Dont include integers in Name. Kindly Enter valid Name : 1");

                            newName = receive(client_id);
                        }
                    }

                    row[3] = newName;
                    compose(client_id, "\nModified Succesfully! But this change is not permanent until you submit valid proof in branch\n\n0");
                }
                else if (x == "4")
                {
                    string newAge;

                    compose(client_id, "Enter Age: 1");
                    newAge = receive(client_id);
                    while (true)
                    {
                        if (!isInteger(newAge))
                        {
                            compose(client_id, "Dont include alphabets in Age. Kindly Enter valid Age : 1");
                            newAge = receive(client_id);
                        }
                        else if (!(stoi(newAge) >= 16 && stoi(newAge) <= 100))
                        {
                            compose(client_id, "Age should be between 16 to 100 years. Kindly Enter valid Age : 1");
                            newAge = receive(client_id);
                        }
                        else
                        {
                            break;
                        }
                    }

                    row[4] = newAge;
                    compose(client_id, "\nModified Succesfully! But this change is not permanent until you submit valid proof in branch\n\n0");
                }
                else
                {
                    compose(client_id, "\nIncorrect option, Try again!\n0");
                }
            }
            if (!fin.eof())
            {
                for (int i = 0; i < n; i++)
                {
                    final.push_back(row[i]);
                }
            }
        }
        else
        {
        }
        if (fin.eof())
        {
            break;
        }
        if (x == "0")
        {
            break;
        }
    }

    fin.close();

    return final; // returns the edited info
}

int dltAccount(string user, int client_id)
{
    fstream fin, fout;

    fin.open("data/sampleFile.csv", ios::in);

    vector<string> row;
    string line, word;

    compose(client_id, "\n\nThe deleted account cannot be retrieved back!\n\n0");
    string pass;

    while (!fin.eof())
    {
        row.clear();
        getline(fin, line);
        stringstream s(line);

        while (getline(s, word, ','))
        {
            row.push_back(word);
        }

        string userid = row[0];

        if (user == userid)
        {
            while (1)
            {
                compose(client_id, "\nEnter password to Confirm:  \n 1");
                pass = receive(client_id);

                if (md5(pass) == row[1]) // if password matches, deletion happens
                {
                    compose(client_id, "\nDeleted Succesfully!\n\n0");

                    return 1;
                }
                else
                {
                    compose(client_id, "\nIncorrect password, Try again!\n0");
                }
            }
        }
        else
        {
        }
        if (fin.eof())
        {
            break;
        }
    }

    fin.close();
    return 0;
}

void signIn(int client_id)
{
    fstream fin, fout, fi, fo, finn, f4i, f4o;

    fin.open("data/sampleFile.csv", ios::in);

    fout.open("data/sampleFile_new.csv", ios::out);

    string user_id, userid, pass;
    int count = 0, k = 0;
    compose(client_id, "\n\n\t***************** Bank Of Kurnool ****************\n\n0");

    compose(client_id, "\n\n\t******* WELCOME BACK! OUR BELOVED Customer *******\n\n0");

    compose(client_id, "\nEnter User ID: \n 1");
    user_id = receive(client_id);

    vector<string> row, r, facc;
    vector<int> cut;
    string line, word, l1, w1;
    int z = 0, dlt = 0;

    while (!fin.eof())
    {
        row.clear();

        getline(fin, line);

        stringstream s(line);

        while (getline(s, word, ','))
        {
            row.push_back(word);
        }

        userid = row[0];

        int n = row.size();

        if (user_id == userid)
        {
            count = 1;

            while (z != 1)
            {
                compose(client_id, "\nPassword: \n 1");
                pass = receive(client_id);

                string hash_Pass = md5(pass); // md5 is a hash based encryption method

                if (hash_Pass == row[1])
                {
                    z = 1;
                    string msg = "";
                    msg += "\n\t******** Profile of " + user_id + " ********\n\n";
                    msg += "\t        Name ->> " + row[3] + "\n";
                    msg += "\t        Account num ->> " + row[2] + "\n";
                    msg += "\t        Age ->> " + row[4] + "\n";
                    msg += "\t        Balance ->> " + row[5] + "\n\n\n0";
                    compose(client_id, msg);
                    string x;

                    while (1)
                    {
                        compose(client_id, "0.Logout, 1.Deposit, 2.Withdraw, 3.Money Transfer, 4.Others:  \n 1");
                        x = receive(client_id);

                        if (x == "0")
                        {
                            compose(client_id, "logout!0");
                            compose(client_id, row[2] + "0");
                            compose(client_id, html_page(row));
                            break;
                        }
                        else if (x == "1")
                        {
                            int dep;
                            compose(client_id, "\nHow much do you want to deposit: \n1"); // depositing operation
                            string temp_bal = receive(client_id);
                            while (!isInteger(temp_bal))
                            {
                                compose(client_id, "Don't include other than integers. Kindly Enter valid amount : 1");
                                temp_bal = receive(client_id);
                            }
                            dep = stoi(temp_bal);

                            int temp = stoi(row[5]);

                            temp = temp + dep;

                            char text[10];
                            sprintf(text, "%d", temp);
                            row[5] = text;

                            string si = ""; // <-- adding the dep to transaction hist
                            si += "+";
                            si += to_string(dep);
                            si += "%";
                            string s2 = text;
                            si += s2;
                            si += "$";
                            time_t now = time(0);
                            char *dt = ctime(&now);
                            string s1 = dt;
                            si += s1;

                            string f = "data/trans" + row[2] + ".csv";

                            string fnew = "data/trans" + row[2] + "_new.csv";

                            fi.open(f, ios::in);
                            fo.open(fnew, ios::out);

                            if (fi.eof())
                            {
                                fo << si << ",";
                                cout << endl;
                            }
                            else
                            {
                                getline(fi, l1);
                                stringstream s(l1);
                                r.clear();

                                while (getline(s, w1, ','))
                                {
                                    r.push_back(w1);
                                }
                                r.push_back(si);

                                int xn = r.size();
                                for (int i = 0; i < xn - 1; i++)
                                {
                                    fo << r[i] << ",";
                                }
                                fo << r[xn - 1] << "\n";
                            }
                            fi.close();
                            fo.close();

                            remove(f.c_str());
                            rename(fnew.c_str(), f.c_str()); // ading to transhhis completed

                            compose(client_id, "\nRemaining balance: " + row[5] + "\n\n0"); // print the balance
                        }
                        else if (x == "2")
                        {
                            int withd;
                            compose(client_id, "\nHow much do you want to withdraw: \n 1"); // withdrawing operation
                            string temp_bal = receive(client_id);
                            while (!isInteger(temp_bal))
                            {
                                compose(client_id, "Don't include other than integers. Kindly Enter valid Balance : 1");
                                temp_bal = receive(client_id);
                            }

                            withd = stoi(temp_bal);

                            int temp = stoi(row[5]);

                            if (temp > withd)
                            {

                                temp = temp - withd;

                                char text[10];

                                sprintf(text, "%d", temp);
                                row[5] = text;
                                string si = ""; // <-- adding the withdraw to transaction hist
                                si += "-";
                                si += to_string(withd);
                                si += "%";
                                string s2 = text;
                                si += s2;
                                si += "$";
                                time_t now = time(0);
                                char *dt = ctime(&now);
                                string s1 = dt;
                                si += s1;
                                string f = "data/trans" + row[2] + ".csv";

                                string fnew = "data/trans" + row[2] + "_new.csv";

                                fi.open(f, ios::in);
                                fo.open(fnew, ios::out);

                                if (fi.eof())
                                {
                                    fo << si << ",";
                                    cout << endl;
                                }
                                else
                                {
                                    getline(fi, l1);
                                    stringstream s(l1);
                                    r.clear();

                                    while (getline(s, w1, ','))
                                    {
                                        r.push_back(w1);
                                    }
                                    r.push_back(si);

                                    int xn = r.size();
                                    for (int i = 0; i < xn - 1; i++)
                                    {
                                        fo << r[i] << ",";
                                    }
                                    fo << r[xn - 1] << "\n";
                                }
                                fi.close();
                                fo.close();

                                remove(f.c_str());
                                rename(fnew.c_str(), f.c_str()); // adding completed
                            }
                            else
                            {
                                compose(client_id, "\nInsufficient balance, Please try again!\n0");
                            }

                            compose(client_id, "\nRemaining balance: " + row[5] + "\n\n0");
                        }
                        else if (x == "3") // money transfer
                        {
                            string m, frndacc;
                            int count1 = 0;
                            compose(client_id, "\nEnter your Recipient's account number:  1"); // enter your friend's 8-digit acc num
                            frndacc = receive(client_id);                                      // f-acc means friend's acc num
                            while (!isInteger(frndacc))
                            {
                                compose(client_id, "Don't include other than integers. Kindly Enter valid Account Number : 1");
                                frndacc = receive(client_id);
                            }

                            if (row[2] == frndacc) // if given acc num matches his own acc num
                            {
                                compose(client_id, "\n*** Don't enter your own account number.\n\n0");
                                continue;
                            }

                            finn.open("data/sampleFile.csv", ios::in); // opened a file for comparing friend acc num

                            vector<string> row1;
                            string line1, word1;

                            while (!finn.eof())
                            {
                                row1.clear();
                                getline(finn, line1);
                                stringstream s1(line1);
                                while (getline(s1, word1, ','))
                                {
                                    row1.push_back(word1);
                                }

                                if (frndacc == row1[2]) // if given facc matches with database acc num
                                {
                                    count1 = 1; // if count1=0 then there is no acc num existing as such

                                    compose(client_id, "\nRECIPIENT's Name: " + row1[3] + "\n\n0");
                                    while (1)
                                    {
                                        compose(client_id, "Proceed (Y/N):  1"); // if the displayed name is not his friend, then he can exit
                                        m = receive(client_id);

                                        if (m == "y" || m == "Y")
                                        {

                                            int temp = stoi(row[5]);
                                            facc.push_back(frndacc); // pushes recipient's account number

                                            int trans;

                                            while (1)
                                            {
                                                compose(client_id, "\nEnter the amount you wish to transfer:  1");
                                                trans = stoi(receive(client_id));

                                                if (temp > trans)
                                                {
                                                    cut.push_back(trans); // pushes money transferred
                                                    temp = temp - trans;  // amount is deducted from his balance
                                                    char text[10];

                                                    sprintf(text, "%d", temp); // used for making a integer to a string
                                                    row[5] = text;
                                                    int bl = trans + stoi(row1[5]);
                                                    string si = ""; // this is for pushing the transaction into parent acc i.e sending acc same as deposition
                                                    si += "#";      // # indicates sending
                                                    si += to_string(trans);
                                                    si += "%";
                                                    string s2 = text;
                                                    si += s2;
                                                    si += "$";
                                                    time_t now = time(0);
                                                    char *dt = ctime(&now);
                                                    string s1 = dt;
                                                    si += s1; // string

                                                    string sii = ""; // this is for pushing the transaction into friend acc i.e sending acc same as deposition
                                                    sii += "@";
                                                    sii += to_string(trans);
                                                    sii += "%";
                                                    string s22 = to_string(bl);
                                                    sii += s22;
                                                    sii += "$";
                                                    time_t now1 = time(0);
                                                    char *dt1 = ctime(&now);
                                                    string s11 = dt;
                                                    sii += s11;
                                                    string f = "data/trans" + row[2] + ".csv"; // open sender transhis file

                                                    string fnew = "data/trans" + row[2] + "_new.csv";
                                                    string f4 = "data/trans" + row1[2] + ".csv"; // open reciever file

                                                    string f4new = "data/trans" + row1[2] + "_new.csv";
                                                    fi.open(f, ios::in);
                                                    fo.open(fnew, ios::out);
                                                    f4i.open(f4, ios::in);
                                                    f4o.open(f4new, ios::out);
                                                    if (fi.eof()) // this is adding new transaction made to sender transaction hist
                                                    {
                                                        fo << si << ",";
                                                        cout << endl;
                                                    }
                                                    else
                                                    {
                                                        getline(fi, l1);
                                                        stringstream s(l1);
                                                        r.clear();

                                                        while (getline(s, w1, ','))
                                                        {
                                                            r.push_back(w1);
                                                        }
                                                        r.push_back(si);

                                                        int xn = r.size();
                                                        for (int i = 0; i < xn - 1; i++)
                                                        {
                                                            fo << r[i] << ",";
                                                        }
                                                        fo << r[xn - 1] << "\n";
                                                    }
                                                    fi.close();
                                                    fo.close();

                                                    remove(f.c_str());
                                                    rename(fnew.c_str(), f.c_str()); // ends here

                                                    if (f4i.eof()) // this is adding new transaction made to sender transaction hist
                                                    {
                                                        f4o << sii << ",";
                                                        cout << endl;
                                                    }
                                                    else
                                                    {
                                                        l1.clear();
                                                        getline(f4i, l1);
                                                        stringstream s(l1);
                                                        r.clear();

                                                        while (getline(s, w1, ','))
                                                        {
                                                            r.push_back(w1);
                                                        }
                                                        r.push_back(sii);

                                                        int xn = r.size();
                                                        for (int i = 0; i < xn - 1; i++)
                                                        {
                                                            f4o << r[i] << ",";
                                                        }
                                                        f4o << r[xn - 1] << "\n";
                                                    }
                                                    f4i.close();
                                                    f4o.close();

                                                    remove(f4.c_str());
                                                    rename(f4new.c_str(), f4.c_str()); // ends here

                                                    break;
                                                }
                                                else
                                                {
                                                    compose(client_id, "\nInsufficient balance, Try again.\n\n0"); // if he enter value bigger than his balance
                                                }
                                            }

                                            compose(client_id, "\nRemaining balance: " + row[5] + "\n\n0");

                                            break;
                                        }
                                        else if (m == "n" || m == "N")
                                        {
                                            compose(client_id, "Transaction denied\n\n0");
                                            break;
                                        }
                                        else
                                        {
                                            compose(client_id, "Incorrect input, Try again later.\n\n0");
                                        }
                                    }

                                    break;
                                }
                                if (finn.eof())
                                {
                                    break;
                                }
                            }
                            if (count1 == 0)
                            {
                                compose(client_id, "\nNo record found with that account number.\n\n0");
                            }

                            finn.close();
                        }
                        else if (x == "4")
                        {
                            string x;
                            while (1)
                            {
                                compose(client_id, "\n0.Go Back, 1.Transaction History, 2.Edit profile, 3.Delete account:  \n 1");
                                x = receive(client_id);

                                if (x == "0")
                                {
                                    printf("\n");
                                    break;
                                }
                                else if (x == "1")
                                {
                                    printf("\n");

                                    string f = "data/trans";
                                    f += row[2];
                                    f += ".csv";
                                    int ir = 0;
                                    fi.open(f, ios::in);
                                    getline(fi, l1);
                                    stringstream s(l1);
                                    string t_history = "";
                                    while (getline(s, w1, ','))
                                    { // traversing through file
                                        ir = 1;
                                        if (w1[0] == '+')
                                        {
                                            t_history += "deposited : ";
                                            int pos = w1.find("%");
                                            int pos1 = w1.find("$");
                                            int k = pos1 - pos;
                                            t_history += w1.substr(1, pos - 1) + "  ";

                                            t_history += "Balance :" + w1.substr(pos + 1, k - 1) + "  ";

                                            t_history += "Time and Date :" + w1.substr(pos1 + 1) + "  \n";
                                        }
                                        else if (w1[0] == '#')
                                        {
                                            t_history += "sent-  ";

                                            int pos = w1.find("%");
                                            int pos1 = w1.find("$");
                                            int k = pos1 - pos;
                                            t_history += w1.substr(1, pos - 1) + " ";

                                            t_history += "Balance :" + w1.substr(pos + 1, k - 1) + "  ";

                                            t_history += "Time and Date :" + w1.substr(pos1 + 1) + "  \n";
                                        }
                                        else if (w1[0] == '@')
                                        {
                                            t_history += "recieved : ";

                                            int pos = w1.find("%");
                                            int pos1 = w1.find("$");
                                            int k = pos1 - pos;
                                            t_history += w1.substr(1, pos - 1) + "  ";

                                            t_history += "Balance :" + w1.substr(pos + 1, k - 1) + "  ";

                                            t_history += "Time and Date :" + w1.substr(pos1 + 1) + "  \n";
                                        }
                                        else
                                        {
                                            t_history += "withdraw-  ";

                                            int pos = w1.find("%");
                                            int pos1 = w1.find("$");
                                            int k = pos1 - pos;
                                            t_history += w1.substr(1, pos - 1) + "  ";

                                            t_history += "Balance :" + w1.substr(pos + 1, k - 1) + "  ";

                                            t_history += "Time and Date :" + w1.substr(pos1 + 1) + "  \n";
                                        }
                                        if (!ir)
                                        {
                                            t_history += "Transaction History is NULL\n";
                                        }
                                    }
                                    compose(client_id, t_history + "0");
                                }
                                else if (x == "2")
                                {
                                    vector<string> edited = editProfile(user_id, client_id); // updating profile
                                    for (int i = 0; i < n - 1; i++)
                                    {
                                        row[i] = edited[i];
                                    }
                                    break;
                                }
                                else if (x == "3")
                                {
                                    dlt = dltAccount(user_id, client_id); // deleting profile
                                    break;
                                }
                                else
                                {
                                    compose(client_id, "Incorrect option, Try again\n\n0");
                                }
                            }
                        }
                        else
                        {
                            compose(client_id, "Incorrect input, Try again!\n0");
                        }
                        if (dlt == 1)
                        {
                            break;
                        }
                    }
                    if (!fin.eof())
                    {
                        if (dlt == 1)
                        {
                            break;
                        }
                        for (int i = 0; i < n - 1; i++)
                        {
                            fout << row[i] << ",";
                        }
                        fout << row[n - 1] << "\n";
                    }
                }
                else
                {
                    compose(client_id, "\nIncorrect password, Please try again!\n\n0");
                }
            }
        }
        else
        {
            if (!fin.eof())
            {
                for (int i = 0; i < n - 1; i++)
                {
                    fout << row[i] << ",";
                }
                fout << row[n - 1] << "\n";
            }
        }
        if (fin.eof())
        {
            break;
        }
    }
    if (count == 0)
    {
        compose(client_id, "No record found\n0"); // if no record is found with that given ID
    }

    fin.close();
    fout.close();

    remove("data/sampleFile.csv"); // old database without changes is deleted

    finn.open("data/sampleFile_new.csv", ios::in); // reads the new database which we recently made changes
    fout.open("data/sampleFile.csv", ios::out);    // writes into that file

    vector<string> row1;
    string line1, word1;
    count = 0;

    while (!finn.eof()) // this function is only made for increasing balance of his friend's account
    {
        row1.clear();
        getline(finn, line1);
        stringstream s1(line1);
        while (getline(s1, word1, ','))
        {
            row1.push_back(word1);
        }
        int n = row1.size();

        for (int i = 0; i < facc.size(); i++)
        {
            if (facc[i] == row1[2]) // checks whether money transfer happened to that account or not
            {
                count = 1;
                int temp = stoi(row1[5]);

                temp = temp + cut[i]; // balance due to money transfer

                char text[10];

                sprintf(text, "%d", temp); // made int to string
                row1[5] = text;

                if (!finn.eof())
                {
                    for (int i = 0; i < n - 1; i++)
                    {
                        fout << row1[i] << ",";
                    }
                    fout << row1[n - 1] << "\n";
                }
            }
        }
        if (count == 0) // if money transfer did'nt happen to that account
        {
            if (!finn.eof())
            {
                for (int i = 0; i < n - 1; i++)
                {
                    fout << row1[i] << ",";
                }
                fout << row1[n - 1] << "\n";
            }
        }
        else
        {
            count = 0;
        }
        if (finn.eof())
        {
            break;
        }
    }

    finn.close();
    fout.close();

    remove("data/sampleFile_new.csv"); // our new database is sampleFile.csv
}

#endif