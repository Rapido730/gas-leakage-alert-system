#ifndef HTML_INVOICE_HPP
#define HTML_INVOICE_HPP


// defined a html_page function to create user bank statement
#include <bits/stdc++.h>

using namespace std;

string html_page(vector<string> row)
{
    string yu;
    fstream fi;
    string g_acc = "data/trans" + row[2] + ".csv";
    // cout << g_acc << endl;
    int ir = 0;
    string l1, w1;
    fi.open(g_acc, ios::in);

    getline(fi, l1);

    stringstream s(l1);
    yu = "";
    yu += "<!DOCTYPE html>\n"; // html syntax
    yu += "<html>\n";
    yu += "<head>";
    yu += "<title>bank</title>\n";
    yu += "<style>\n";
    yu += "body {background-color: powderblue;}\n";
    yu += "body { text-align-last:center;}\n";
    yu += "</style>\n";
    yu += "</head>\n";
    yu += "<body>\n"; // until here plainsyntax
    // yu+="<center>\n";
    yu += "<h1>Thanks for visiting Bank of Kurnool dear " + row[3] + "</h1>\n"; // first line row[i]->name of the customer
    yu += "<hr>\n";                                                             // adds a line
    yu += "<h1>Here are your details:</h1>\n";
    yu += "<hr>\n";
    yu += "<h2>User ID - " + row[0] + "</h2>\n";        // here row[i] is the name of customer
    yu += "<h2>Account_Number - " + row[2] + "</h2>\n"; // row[i]->account number
    yu += "<hr>\n";

    yu += "<h1>Transaction History:</h1>\n";
    yu += "<hr>\n";
    int io = 0;
    while (getline(s, w1, ',')) // here is traversing the transhistory and adding it html string "yu"
    {

        ir = 1;
        int pos = w1.find("%");
        int pos1 = w1.find("$");
        int k = pos1 - pos;
        if (!io)
        {
            yu += "<h2>Transactions &emsp;&emsp;Date and Time &emsp;&emsp; Balance</h2>\n";
            io = 1;
        }
        if (w1[0] == '+')
        {
            yu += "<h3>Deposited -> " + w1.substr(1, pos - 1) + " - Rs &emsp;&emsp;" + w1.substr(pos1 + 1) + "&emsp;&emsp;" + w1.substr(pos + 1, k - 1) + "-Rs</h3>\n";
        }
        else if (w1[0] == '#')
        {
            yu += "<h3>Sent -> " + w1.substr(1, pos - 1) + " - Rs &emsp;&emsp;" + w1.substr(pos1 + 1) + "&emsp;&emsp;" + w1.substr(pos + 1, k - 1) + "-Rs</h3>\n";
        }
        else if (w1[0] == '@')
        {
            yu += "<h3>Recieved -> " + w1.substr(1, pos - 1) + " - Rs &emsp;&emsp;" + w1.substr(pos1 + 1) + "&emsp;&emsp;" + w1.substr(pos + 1, k - 1) + "-Rs</h3>\n";
        }
        else
        {
            yu += "<h3>Withdrawl -> " + w1.substr(1, pos - 1) + " - Rs &emsp;&emsp;" + w1.substr(pos1 + 1) + "&emsp;&emsp;" + w1.substr(pos + 1, k - 1) + "-Rs</h3>\n";
        }
    }
    if (!ir) // if transhist is empty
    {
        yu += "<h1>Transaction History is Empty</h1>\n";
    }
    yu += "<hr>\n";
    yu += "<h1>Remaining Balance:</h1>\n";
    yu += "<hr>\n";
    yu += "<h2>" + row[5] + " - Rs only</h2>\n"; // row[i]->balance
    yu += "<hr>\n";

    yu += "</body>\n";
    yu += "</html>\n";
    return yu;
}

#endif
