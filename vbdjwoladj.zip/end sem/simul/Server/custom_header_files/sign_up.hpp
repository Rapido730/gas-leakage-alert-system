#include <bits/stdc++.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "comp_rece.hpp"
#include "md5.h"
#include "validation.hpp"

using namespace std;

// sign up function

// Server side

void signUp(int client_id)
{
    string data;
    fstream fin, fout, finn;

    fout.open("data/sampleFile.csv", ios::out | ios::app); // taking file as input stream
    fin.open("data/sampleFile.csv", ios::in);
    finn.open("data/sampleFile.csv", ios::in);

    srand((unsigned)time(NULL));

    long int x = 10000000;

    int bal, length;
    string age;
    long int acc;
    string user_id, pass, pass1, name;

    compose(client_id, "\n\n\t******** Trust is the only thing we sell ********\n\n0");

    // receiving

    compose(client_id, "Create an User Id : 1"); // sending
    while (1)                                    // Creates account by gathering all info
    {
        user_id = receive(client_id);

        vector<string> row;
        string line, word;
        int count = 0;

        fin.seekg(0, ios::end); // file points to the end
        int length = fin.tellg();

        if (length != 0)
        {
            fin.seekg(0, ios::beg); // file points to the beginning
   
            while (!fin.eof())
            {
                row.clear();

                getline(fin, line); // obtains a line in the file

                stringstream s(line);

                while (getline(s, word, ','))
                {
                    row.push_back(word); // splits and pushes to vector
                }

                string userid = row[0];

                int n = row.size();

                if (user_id == userid) // if entered ID matches previous IDs
                {
                    count = 1;
                    break;
                }

                if (fout.eof()) // end of file
                {
                    break;
                }
            }
            if (count == 0)
            {
                break;
            }
            else
            {
                // printf("\nUser ID already in use, choose another!\n\n");
                compose(client_id, "\nUser ID already in use, choose another!\n\nEnter Account number: 1");
            }
        }
        else
        {
            break;
        }
    }

    while (1)
    {
        acc = rand() % (x + 1) + x; // random 8 digits number generation

        vector<string> row;
        string line, word;
        int count = 0;

        finn.seekg(0, ios::end);
        int length = finn.tellg();

        if (length != 0)
        {
            finn.seekg(0, ios::beg);

            while (!finn.eof())
            {
                row.clear();

                getline(finn, line);

                stringstream s(line);

                while (getline(s, word, ','))
                {
                    row.push_back(word);
                }

                long int ab = stoi(row[2]);

                int n = row.size();

                if (acc == ab) // checks for uniqueness
                {
                    count = 1;
                    break;
                }

                if (fout.eof())
                {
                    break;
                }
            }
            if (count == 0)
            {
                break;
            }
        }
        else
        {
            break;
        }
    }

    while (1)
    {
        compose(client_id, "Enter Password: 1");
        pass = receive(client_id);
        while (pass.length() < 8)
        {
            compose(client_id, "Password is too short. Password length should be atleast 8.\n Try again1");
            pass = receive(client_id);
        }

        compose(client_id, "Confirm Password: 1");
        pass1 = receive(client_id);

        if (pass == pass1)
        {
            break;
        }
        else
        {
            compose(client_id, "Type the same password again!\n\n0");
        }
    }

    compose(client_id, "Enter Name: 1");
    name = receive(client_id);
    while (!isChars(name) || name.length() > 50)
    {
        if (name.length() > 50)
        {
            compose(client_id, "Name is too long. Kindly Enter valid Name : 1");
            name = receive(client_id);
        }
        else
        {
            compose(client_id, "Dont include integers in name. Kindly Enter valid Name : 1");
  
            name = receive(client_id);
        }
    }

    compose(client_id, "Enter Age: 1");
    age = receive(client_id);
    while (true)
    {
        if (!isInteger(age))
        {
            compose(client_id, "Dont include alphabets in Age. Kindly Enter valid Age : 1");
            age = receive(client_id);
        }
        else if (!(stoi(age) >= 16 && stoi(age) <= 100))
        {
            compose(client_id, "Age should be between 16 to 100 years. Kindly Enter valid Age : 1");
            age = receive(client_id);
        }
        else
        {
            break;
        }
    }

    compose(client_id, "Enter amount of first Cash deposit: 1");
    string temp_bal = receive(client_id);
    while (!isInteger(temp_bal))
    {
        compose(client_id, "Don't include other than integers. Kindly Enter valid Balance : 1");
        temp_bal = receive(client_id);
    }
    bal = stoi(temp_bal);

    fout << user_id << "," << md5(pass) << "," << acc << "," << name << "," << age << "," << bal << endl;
    cout << acc << "," << pass << "," << name << "," << age << "," << bal << endl;
}
