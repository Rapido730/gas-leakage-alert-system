g++ server1.cpp -o server1 custom_header_files/md5.cpp && ./server1

