#include <bits/stdc++.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "custom_header_files/sign_up.hpp"
#include "custom_header_files/sign_in.hpp"

using namespace std;

// Server side

int port = 3000;

sockaddr_in servAddr;
int serverSd, socket_id;

map<string, vector<string>> mp;

int count;

int bank(int client_id)
{

    while (1)
    {

        

        compose(client_id, "0.Exit, 1.SignUp, 2.SignIn:  1");
        string x = receive(client_id); // receiving response
        if(x=="$%^&"){
            return 0;
        }
        if (x == "0")
        {
            cout << "Client has quit the session" << endl;
            compose(client_id, "exit!0");
            return 0;
        }
        else if (x == "1")
        {

            signUp(client_id);
        }
        else if (x == "2")
        {

            signIn(client_id);
        }
        else
        {
            compose(client_id, "\nIncorrect input, Try again!\n0");
        }
    }

    return 0;
}

// function to accept client and initiate bank function
void bank_utility()
{
    sockaddr_in newSockAddr;
    socklen_t newSockAddrSize = sizeof(newSockAddr);

    // accept, create a new socket descriptor to
    // handle the new connection with client

    int client_id = accept(socket_id, (sockaddr *)&newSockAddr, &newSockAddrSize);

    if (client_id < 0)
    {
        cerr << "Error accepting request from client!" << endl;
        exit(1);
    }

    cout << "Connected with client!" << endl;
    cout << "Awaiting client response..." << endl;

    bank(client_id); // initiating bank function with client id
    cout<< "client disconnected!"<<endl;
    close(client_id);
}

int main()
{
    ios::sync_with_stdio(false);

    // setup a socket and connection tools
    //  sockaddr_in servAddr;
    bzero((char *)&servAddr, sizeof(servAddr));

    // assign IP, PORT
    servAddr.sin_family = AF_INET;                // AF_IFNET address is used when tcp or udp used;
    servAddr.sin_addr.s_addr = htonl(INADDR_ANY); // ipaddress is given here , but INADDR_ANY is given when we dont need to connect
    servAddr.sin_port = htons(port);              // port number

    // open stream oriented socket with internet address
    // also keep track of the socket descriptor

    // socket create and verification
    socket_id = socket(AF_INET, SOCK_STREAM, 0); // AF_INET for IPV4 and for same host use AF_LOCAL
                                                 // SOCK_STREAM is used for TCP and SOCK_DGRAM for UDP
                                                 // last parameter is ip whose value is 0.

    if (socket_id < 0)
    {
        cerr << "Error establishing the server socket" << endl;
        exit(0);
    }
    int bind_status;
    // Binding newly created socket to given IP and verification
    while (1)
    {
        bind_status = bind(socket_id, (struct sockaddr *)&servAddr, sizeof(servAddr));
        if(bind_status==0)
        {
            break;
        }
        else{
            ++port;
            // bzero((char *)&servAddr, sizeof(servAddr));

            // // assign IP, PORT
            // servAddr.sin_family = AF_INET;                
            // servAddr.sin_addr.s_addr = htonl(INADDR_ANY); 
            servAddr.sin_port = htons(port);              
        }
        
    }
    
    printf("Socket successfully binded and waiting for client to connect on port %d...\n",port);

    // listen for up to 1000 requests at a time
    listen(socket_id, 1000);

    // creating and array of 100 threads
    thread th1[100];
    int ind = 0;
    while (ind < 100)
    {
        th1[ind++] = thread(bank_utility); // initiating every thread which will execute bank_utility function
    }

    ind = 0;
    while (ind < 100)
    { // when every thread will be completed then we will join all threads
        th1[ind++].join();
    }

    close(socket_id); // closing socket id
    cout << "********Session********" << endl;
    cout << "Connection closed..." << endl;

    return 0;
}
