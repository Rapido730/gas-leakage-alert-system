
#ifndef COMP_RECE_HPP
#define COMP_RECE_HPP



#include <bits/stdc++.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

// #ifndef COMP_RECE_HPP
// #define COMP_RECE_HPP
// #ifdef _WIN32
// #pragma once
// #endif

using namespace std;

// Server side

// send function which takes socket id and string and send message
void compose(int id, string str)
{
    char msg[1500];
    string data = str;
    strcpy(msg, data.c_str());
    send(id, (char *)&msg, sizeof(msg), 0);
    memset(&msg, 0, sizeof(msg)); // clear the buffer
}

// receive function which take socket id as input and receive a message and return message as a string
string receive(int id)
{
    char msg[1500];
    recv(id, (char *)&msg, sizeof(msg), 0);
    string data = msg;
    memset(&msg, 0, sizeof(msg)); // clear the buffer
    return data;
}

#endif