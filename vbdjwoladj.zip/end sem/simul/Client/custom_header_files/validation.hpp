#ifndef VALIDATION_HPP
#define VALIDATION_HPP

#include <bits/stdc++.h>

bool isInteger(string s)
{
    for (char c : s)
    {
        if (c >= '0' && c <= '9')
        {
        }
        else
        {
            return false;
        }
    }
    return true;
}

bool isChars(string s)
{
    for (char c : s)
    {
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
        {
        }
        else
        {
            return false;
        }
    }
    return true;
}

#endif