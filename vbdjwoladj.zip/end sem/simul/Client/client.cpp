
#include <bits/stdc++.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "custom_header_files/comp_rece.hpp"
#include "custom_header_files/validation.hpp"

using namespace std;
// Client side

int main()
{
    string Ip;
    cout << "Enter Server IP Address : ";
    cin >> Ip;

    int port = 3000;
    string tempPort = "";

    cout << "Enter Port number : ";
    while (1)
    {
        cin >> tempPort;
        if (isInteger(tempPort))
        {
            port = stoi(tempPort);
            break;
        }
        else
        {
            cout << "Enter Valid Port number : ";
        }
    }

    char serverIp[100] = "127.0.0.1";
    strcpy(serverIp, Ip.c_str());

    // setup a socket and connection tools
    // struct hostent *host = gethostbyname(serverIp);
    sockaddr_in sendSockAddr;
    bzero((char *)&sendSockAddr, sizeof(sendSockAddr));
    // sendSockAddr.sin_family = AF_INET;
    // sendSockAddr.sin_addr.s_addr =
    //     inet_addr(inet_ntoa(*(struct in_addr *)*host->h_addr_list));
    // sendSockAddr.sin_port = htons(port);

    sendSockAddr.sin_family = AF_INET;                  // AF_IFNET address is used when tcp or udp used;
    sendSockAddr.sin_addr.s_addr = inet_addr(serverIp); // ipaddress is given here , but INADDR_ANY is given when we dont need to connect
    sendSockAddr.sin_port = htons(port);                // port number

    int server_id = socket(AF_INET, SOCK_STREAM, 0);
    // try to connect...
    int status = connect(server_id,
                         (sockaddr *)&sendSockAddr, sizeof(sendSockAddr));
    if (status < 0)
    {
        cout << "Error connecting to socket!" << endl;
        return -1;
    }
    cout << "Connected to the server!" << endl;
    int flag = 0;
    string html;
    fstream html_writer;

    while (1)
    {
        if (flag == 0)
        {
            string data = receive(server_id);
            flag = data[data.length() - 1] - '0';
            data = data.substr(0, data.length() - 1);
            cout << data << endl;
            if (data == "logout!")
            {
                string acc = receive(server_id);
                string file_name = "Statement" + acc + ".html";

                html_writer.open(file_name, ios::out); // opening the file y

                html = receive(server_id);
                html = html.substr(0, html.length() - 1);
                html_writer << html << "\n";
                html_writer.close();
            }
            if (data == "exit!")
            {
                break;
            }
        }
        else
        {
            string data;
            cout << "> ";
            cin >> data;
            compose(server_id, data);
            flag = 0;
        }
    }

    close(server_id);
    cout << "********Session********" << endl;
    cout << "Connection closed" << endl;
    return 0;
}