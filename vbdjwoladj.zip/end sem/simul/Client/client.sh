g++ client.cpp -o client && ./client
