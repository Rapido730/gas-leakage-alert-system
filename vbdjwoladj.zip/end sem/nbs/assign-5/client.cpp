
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <bits/stdc++.h>
using namespace std;

#define PORT 8888
#define MAXLINE 1024

int sendrequest(int sockfd)
{
    char buff[MAXLINE];
    int p;
    int n = 0;

    while (true)
    {
        printf("\nEnter number of pairs : ");
        cin >> p;
        while ((buff[n++] = getchar()) != '\n')
            ;

        if (p > 1)
            break;
        else
            cout << "please enter number greater than 1\n";
    }
    int pairs[100];
    pairs[0] = p;
    write(sockfd, pairs, 100);

    for (int i = 0; i < p; i++)
    {
        printf("\npoint %d : \n", i + 1);

        printf("\nEnter the value of x : ");

        bzero(buff, sizeof(buff));
        n = 0;
        while ((buff[n++] = getchar()) != '\n')
            ;

        if ((strncmp(buff, "exit", 4)) == 0)
        {
            printf("Client Exit...\n");
            write(sockfd, buff, sizeof(buff));
            break;
        }
        write(sockfd, buff, sizeof(buff));
        bzero(buff, sizeof(buff));

        printf("\nEnter the value of y : ");
        bzero(buff, sizeof(buff));
        n = 0;
        while ((buff[n++] = getchar()) != '\n')
            ;

        if ((strncmp(buff, "exit", 4)) == 0)
        {
            printf("Client Exit...\n");
            write(sockfd, buff, sizeof(buff));
            break;
        }
        write(sockfd, buff, sizeof(buff));
        bzero(buff, sizeof(buff));
    }
    int nums[100];
    read(sockfd, nums, 100);
    double dis = pow(nums[4], 0.5);

    printf("\nFrom Server :  closest point are \n {%d, %d} and {%d, %d } having distance = %f\n", nums[0], nums[1], nums[2], nums[3], dis);
    printf("\nType \"exit\" to exit or type any key to calculate again !\n>");
    bzero(buff, sizeof(buff));
    n = 0;
    while ((buff[n++] = getchar()) != '\n')
        ;

    if ((strncmp(buff, "exit", 4)) == 0)
    {
        printf("Client Exit...\n");
        write(sockfd, buff, sizeof(buff));
        return 0;
    }
    write(sockfd, buff, sizeof(buff));
    return 1;
}

int main()
{

    int sockfd;
    char buffer[MAXLINE];

    struct sockaddr_in servaddr;

    int n, len;
    // Creating socket file descriptor
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        printf("socket creation failed");
        exit(0);
    }

    memset(&servaddr, 0, sizeof(servaddr));

    // Filling server information
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT);
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(sockfd, (struct sockaddr *)&servaddr,
                sizeof(servaddr)) < 0)
    {
        printf("\n Error : Connect Failed \n");
        return 0;
    }
    int flag = 0;

    while (sendrequest(sockfd))
        ;
    close(sockfd);
}
