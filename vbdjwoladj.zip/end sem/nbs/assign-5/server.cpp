
#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <signal.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <bits/stdc++.h>
using namespace std;

#define PORT 2323
#define MAXLINE 1024
int max(int x, int y)
{
    if (x > y)
        return x;
    else
        return y;
}
char *integerTostring(int num)
{
    string s;
    int i = 0;
    while (num)
    {
        int rem = num % 10;
        num = num / 10;
        string temp(1, ((char)(rem + '0')));
        s = temp + s;
    }
    char buff[MAXLINE];
    strcpy(buff, s.c_str());
    return buff;
}

void solve(int nums[], int n, int sockfd)
{

    int p1, p2;
    int mini = 1e9;

    for (int i = 0; i < n - 2; i += 2)
    {
        for (int j = i + 2; j < n; j += 2)
        {
            int x1 = nums[i], y1 = nums[i + 1], x2 = nums[j], y2 = nums[j + 1];
            int dis = (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2);
            if (mini > dis)
            {
                p1 = i;
                p2 = j;
                mini = dis;
            }
        }
    }
    double mini_dis = pow(mini, 0.5);
    double dis[1] = {mini_dis};
    int num = mini;
    int buff[100] = {nums[p1], nums[p1 + 1], nums[p2], nums[p2 + 1], num};

    printf("\nTo client :  closest point are \n {%d, %d} and {%d, %d } having distance = %f\n", buff[0], buff[1], buff[2], buff[3], mini_dis);
    write(sockfd, buff, 100);
}

int HandleRequest(int sockfd, int len)
{
    char buff[MAXLINE];
    int n;
    int pairs[100];

    read(sockfd, pairs, sizeof(pairs));
    n = 2 * pairs[0];

    int nums[n];

    for (int i = 0; i < n; i++)
    {

        bzero(buff, MAXLINE);
        read(sockfd, buff, sizeof(buff));

        printf("\nclient input : %s", buff);
        if (strncmp("exit", buff, 4) == 0)
        {
            printf("client is Exiting...\n");
            bzero(buff, MAXLINE);
            close(sockfd);
            break;
        }
        else
        {
            int num = 0;
            int j = 0;
            while (buff[j] != '\n')
            {
                num = num * 10 + (int)(buff[j] - '0');
                j++;
            }

            nums[i] = num;
        }
    }

    solve(nums, n, sockfd);
    bzero(buff, MAXLINE);
    read(sockfd, buff, sizeof(buff));
    if (strncmp("exit", buff, 4) == 0)
    {
        printf("\nclient is Exiting...\n");
        bzero(buff, MAXLINE);
        close(sockfd);
        return 0;
    }
    return 1;
}

int main()
{
    int listenfd, connfd, sd_ready, maxfdp1;
    char buffer[MAXLINE];
    pid_t childpid;
    fd_set rset;
    ssize_t n;
    socklen_t len;
    const int on = 1;
    struct sockaddr_in cliaddr, servaddr;

    void sig_chld(int);

    /* create listening TCP socket */
    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(PORT);

    // binding server addr structure to listenfd
    bind(listenfd, (struct sockaddr *)&servaddr, sizeof(servaddr));
    listen(listenfd, 1000);
    printf("Server is listening to Port %d\n", PORT);
    // clear the descriptor set
    FD_ZERO(&rset);

    // get maxfd
    maxfdp1 = listenfd + 1;
    for (;;)
    {

        FD_SET(listenfd, &rset);

        sd_ready = select(maxfdp1, &rset, NULL, NULL, NULL);

        if (FD_ISSET(listenfd, &rset))
        {
            len = sizeof(cliaddr);
            connfd = accept(listenfd, (struct sockaddr *)&cliaddr, &len);
            printf("\nNew connection with Socket ID =  %d, IP = %s, Port : %d\n", connfd, inet_ntoa(cliaddr.sin_addr), ntohs(cliaddr.sin_port));
            if ((childpid = fork()) == 0)
            {
                close(listenfd);

                while (HandleRequest(connfd, sizeof(cliaddr)))
                    ;

                close(connfd);
                exit(0);
            }
            close(connfd);
        }
    }
}
