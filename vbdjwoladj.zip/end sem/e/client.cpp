#include <bits/stdc++.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>


using namespace std;

void compose(int id, string str)
{
    char msg[1500];
    string data = str;
    strcpy(msg, data.c_str());
    int sent_bytes = send(id, (char *)&msg, sizeof(msg), 0);
    memset(&msg, 0, sizeof(msg)); // clear the buffer
}

// receive function which take socket id as input and receive a message and return message as a string
string receive(int id)
{
    char msg[1500];
    int flag = recv(id, (char *)&msg, sizeof(msg), 0);
    string data = msg;
    memset(&msg, 0, sizeof(msg)); // clear the buffer
    return data;
}

int main()
{

    sockaddr_in server_addr;

    bzero((char *)&server_addr, sizeof(server_addr));

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    server_addr.sin_port = htons(3000);

    int server_id = socket(AF_INET, SOCK_STREAM, 0);

    int status = connect(server_id, (sockaddr *)&server_addr, sizeof(sockaddr));

    if (status < 0)
    {
        cout << "Error connecting to socket \n";
        return -1;
    }
    cout << "connected to server\n";

    while (true)
    {

        cout << receive(server_id);
        string s;
        cin >> s;
        compose(server_id, s);
    }

    close(server_id);
    cout << "connection closed";
    return 0;
}
