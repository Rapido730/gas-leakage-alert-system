#include <bits/stdc++.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

using namespace std;

int port = 3000;

sockaddr_in server_addr;
int server_sd, socket_id;

void compose(int id, string str)
{
    char msg[1500];
    string data = str;
    strcpy(msg, data.c_str());
    int sent_bytes = send(id, (char *)&msg, sizeof(msg), 0);
    memset(&msg, 0, sizeof(msg)); // clear the buffer
}

// receive function which take socket id as input and receive a message and return message as a string
string receive(int id)
{
    char msg[1500];
    int flag = recv(id, (char *)&msg, sizeof(msg), 0);
    string data = msg;
    memset(&msg, 0, sizeof(msg)); // clear the buffer
    return data;
}

void handle(int client_id)
{

    while (true)
    {
        string s;
        cin >> s;
        compose(client_id, s);
        cout << receive(client_id);
    }
}

int main()
{

    bzero((char *)&server_addr, sizeof(server_addr));

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_port = htons(port);

    socket_id = socket(AF_INET, SOCK_STREAM, 0);

    if (socket_id < 0)
    {
        cout << "error establishing the server socket \n";
        exit(0);
    }

    int bind_status = bind(socket_id, (struct sockaddr *)&server_addr, sizeof(server_addr));

    if (bind_status != 0)
    {
        cout << "error in socket binding \n";
        exit(0);
    }

    listen(socket_id, 1000);

    sockaddr_in client_addr;
    socklen_t addr_size = sizeof(client_addr);

    while (true)
    {

        int client_id = accept(socket_id, (sockaddr *)&client_addr, &addr_size);

        if (client_id < 0)
        {
            cout << "error in connecting to client\n";
            exit(1);
        }
        else
        {
            if (fork() == 0)
            {
                close(socket_id);
                handle(client_id);
            }
        }
    }
    // thread arr[100];

    // for(int i=0;i<100;i++){
    //     arr[i] = thread(handle);
    // }

    // for(int i=0;i<100;i++){
    //     arr[i].join();
    // }

    // handle(client_id);

    // close(client_id);

    close(socket_id);
}