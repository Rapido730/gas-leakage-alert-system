#include <bits/stdc++.h>
using namespace std;


void show_queue(priority_queue<pair<int, int>> memory)
{
    vector<pair<int,int>> v;
    while(!memory.empty()){
        v.push_back(memory.top());
        cout << memory.top().second<<"    ";
        memory.pop();
    }
    cout<<endl;
    // for(auto it:v){
    //     memory.push(it);
    // }
}
void heap_delete(priority_queue<pair<int, int>> &memory, int page_ref)
{
    vector<pair<int, int>> v;
    while (!memory.empty())
    {
        if (memory.top().second != page_ref)
            v.push_back(memory.top());
        // cout << memory.top().second<<"    ";
        memory.pop();
    }
    for (auto it : v)
    {
        memory.push(it);
    }
}
void optimal(vector<int> &pages, int win_size)
{
    priority_queue<pair<int, int>> memory;

    unordered_map<int, bool> present;
    int hit = 0, miss = 0;
    int i = 0;
    while (i < pages.size())
    {
        if (present.find(pages[i]) == present.end() || present[pages[i]] == false)
        {
            memory.push({-i, pages[i]});
            present[pages[i]] = true;
            miss++;
            // cout<<pages[i]<<endl;
        }
        else
        {
            heap_delete(memory, pages[i]);
            memory.push({-i, pages[i]});
            hit++;
        }
        while (memory.size() > win_size)
        {
            int page_ref = memory.top().second;
            // cout<<page_ref<<endl;
            present[page_ref] = false;
            memory.pop();
        }
        i++;
        // cout<<pages[i-1]<<" :->  ";
        // show_queue(memory);
    }

    cout << hit << " " << miss;
}

int main()
{
    int n, win_size;
    cin >> n;
    cin >> win_size;
    vector<int> pages(n);
    for (int i = 0; i < n; i++)
    {
        cin >> pages[i];
    }
    optimal(pages, win_size);
}