#include <bits/stdc++.h>
using namespace std;

class process
{
public:
    int pid;
    int bt;
    int at;
    int ct;
    int tat;
    int rem_bt;
    int wt;
    int priority;

    process(int v1, int v2, int v3, int v4)
    {
        pid = v1;
        at = v2;
        bt = v3;
        rem_bt = v3;
        priority = v4;
    }

    process(int v1, int v2, int v3)
    {
        pid = v1;
        at = v2;
        bt = v3;
        rem_bt = v3;
        priority = 0;
    }
};

struct compareFcfs
{
    bool operator()(process *a, process *b)
    {
        return a->at > b->at;
    }
};

struct compareSjf
{
    bool operator()(process *a, process *b)
    {
        return a->bt > b->bt;
    }
};

struct compareSrtf
{
    bool operator()(process *a, process *b)
    {
        return a->rem_bt != b->rem_bt ? a->rem_bt > b->rem_bt : (a->at > b->at);
    }
};

struct comparePriority
{
    bool operator()(process *a, process *b)
    {
        return a->priority < b->priority;
    }
};

struct comparePrePri
{
    bool operator()(process *a, process *b)
    {
        return a->priority != b->rem_bt ? a->priority < b->priority : (a->at > b->at);
    }
};

void fcfs(vector<process *> pcb, int &time)
{
    priority_queue<process *, vector<process *>, compareFcfs> pq;

    for (auto it : pcb)
    {
        pq.push(it);
    }
    cout << endl;

    vector<int> gantt_chart;

    while (!pq.empty())
    {
        vector<process *> temp;

        auto it = pq.top();
        pq.pop();

        if (time < it->at)
        {
            time = it->at;
        }

        if (it->at <= time)
        {
            int ct = time + it->bt;
            int tat = ct - it->at;
            int wt = tat - it->bt;
            time = ct;
            it->ct = ct;
            it->tat = tat;
            it->wt = wt;
            int t = it->bt;
            while (t--)
                gantt_chart.push_back(it->pid);
        }
        else
        {
            pq.push(it);
        }
    }

    for (auto it : pcb)
    {

        cout << it->pid << " " << it->at << " " << it->bt << " " << it->ct << " " << it->tat << " " << it->wt << endl;
    }

    cout << endl;
    for (int it : gantt_chart)
    {

        cout << "P" << it << " ";
    }
}

void sjf(vector<process *> pcb, int &time)
{
    priority_queue<process *, vector<process *>, compareSjf> pq;

    for (auto it : pcb)
    {
        pq.push(it);
    }
    cout << endl;

    vector<int> gantt_chart;

    while (!pq.empty())
    {
        vector<process *> temp;

        auto it = pq.top();
        pq.pop();

        while (!(it->at <= time))
        {
            temp.push_back(it);
            it = pq.top();
            pq.pop();
        }

        if (it->at <= time)
        {
            int ct = time + it->bt;
            int tat = ct - it->at;
            int wt = tat - it->bt;
            time = ct;
            it->ct = ct;
            it->tat = tat;
            it->wt = wt;
            int t = it->bt;
            while (t--)
                gantt_chart.push_back(it->pid);
            if (temp.size())
            {
                for (auto t : temp)
                    pq.push(t);
            }
        }
        else
        {
            pq.push(it);
        }
    }

    for (auto it : pcb)
    {

        cout << it->pid << " " << it->at << " " << it->bt << " " << it->ct << " " << it->tat << " " << it->wt << endl;
    }

    cout << endl;
    for (int it : gantt_chart)
    {

        cout << "P" << it << " ";
    }
}

void srtf(vector<process *> pcb, int &time)
{
    priority_queue<process *, vector<process *>, compareSrtf> pq;

    for (auto it : pcb)
    {
        pq.push(it);
    }
    cout << endl;

    vector<int> gantt_chart;

    while (!pq.empty())
    {
        vector<process *> temp;

        auto it = pq.top();
        pq.pop();

        while (!(it->at <= time))
        {
            temp.push_back(it);
            it = pq.top();
            pq.pop();
        }

        if (it->at <= time)
        {
            it->rem_bt--;
            time++;
            gantt_chart.push_back(it->pid);

            if (it->rem_bt == 0)
            {
                int ct = time;
                int tat = ct - it->at;
                int wt = tat - it->bt;

                it->ct = ct;
                it->tat = tat;
                it->wt = wt;
            }
            else
            {
                pq.push(it);
            }

            if (temp.size())
            {
                for (auto t : temp)
                    pq.push(t);
            }
        }
        else
        {
            pq.push(it);
        }
    }

    for (auto it : pcb)
    {

        cout << it->pid << " " << it->at << " " << it->bt << " " << it->ct << " " << it->tat << " " << it->wt << endl;
    }

    cout << endl;
    for (int it : gantt_chart)
    {

        cout << "P" << it << " ";
    }
}

void priority(vector<process *> pcb, int &time)
{
    priority_queue<process *, vector<process *>, comparePriority> pq;

    for (auto it : pcb)
    {
        pq.push(it);
    }
    cout << endl;

    vector<int> gantt_chart;

    while (!pq.empty())
    {
        vector<process *> temp;

        auto it = pq.top();
        pq.pop();

        while (!(it->at <= time))
        {
            temp.push_back(it);
            it = pq.top();
            pq.pop();
        }

        if (it->at <= time)
        {
            int ct = time + it->bt;
            int tat = ct - it->at;
            int wt = tat - it->bt;
            time = ct;
            it->ct = ct;
            it->tat = tat;
            it->wt = wt;
            int t = it->bt;
            while (t--)
                gantt_chart.push_back(it->pid);
            if (temp.size())
            {
                for (auto t : temp)
                    pq.push(t);
            }
        }
        else
        {
            pq.push(it);
        }
    }

    for (auto it : pcb)
    {

        cout << it->pid << " " << it->at << " " << it->bt << " " << it->ct << " " << it->tat << " " << it->wt << endl;
    }

    cout << endl;
    for (int it : gantt_chart)
    {

        cout << "P" << it << " ";
    }
}

void PreemptivePriority(vector<process *> pcb, int &time)
{
    priority_queue<process *, vector<process *>, comparePrePri> pq;

    for (auto it : pcb)
    {
        pq.push(it);
    }
    cout << endl;

    vector<int> gantt_chart;

    while (!pq.empty())
    {
        vector<process *> temp;

        auto it = pq.top();
        pq.pop();

        while (!(it->at <= time))
        {
            temp.push_back(it);
            it = pq.top();
            pq.pop();
        }

        if (it->at <= time)
        {
            it->rem_bt--;
            time++;
            gantt_chart.push_back(it->pid);

            if (it->rem_bt == 0)
            {
                int ct = time;
                int tat = ct - it->at;
                int wt = tat - it->bt;

                it->ct = ct;
                it->tat = tat;
                it->wt = wt;
            }
            else
            {
                pq.push(it);
            }

            if (temp.size())
            {
                for (auto t : temp)
                    pq.push(t);
            }
        }
        else
        {
            pq.push(it);
        }
    }

    for (auto it : pcb)
    {

        cout << it->pid << " " << it->at << " " << it->bt << " " << it->ct << " " << it->tat << " " << it->wt << endl;
    }

    cout << endl;
    for (int it : gantt_chart)
    {

        cout << "P" << it << " ";
    }
}

void RoundRobin(vector<process *> pcb, int &time, int time_slice)
{
    queue<process *> q;

    for (auto it : pcb)
    {
        q.push(it);
    }

    cout << endl;

    vector<int> gantt_chart;

    while (!q.empty())
    {

        auto it = q.front();
        q.pop();
        if (it->at <= time)
        {

            int time_consumed = min(time_slice, it->rem_bt);
            it->rem_bt -= time_consumed;
            time += time_consumed;
            gantt_chart.push_back(it->pid);

            if (it->rem_bt == 0)
            {
                int ct = time;
                int tat = ct - it->at;
                int wt = tat - it->bt;

                it->ct = ct;
                it->tat = tat;
                it->wt = wt;
            }
            else
            {
                q.push(it);
            }
        }
        else
        {
            q.push(it);
        }
    }

    for (auto it : pcb)
    {

        cout << it->pid << " " << it->at << " " << it->bt << " " << it->ct << " " << it->tat << " " << it->wt << endl;
    }

    cout << endl;
    for (int it : gantt_chart)
    {

        cout << "P" << it << " ";
    }
}

int main()
{

    vector<process *> pcb[6];
    int n = 6;
    int mini = INT_MAX;
    int time_slice;
    for (int j = 0; j < 6; j++)
    {
        if (j == 3 || j == 4)
            for (int i = 0; i < n; i++)
            {
                int pid;
                int at;
                int bt;
                int pri;
                cin >> pid >> at >> bt >> pri;
                pcb[j].push_back(new process(pid, at, bt, pri));
                mini = min(mini, at);
            }
        else
        {
            if (j == 5)
                cin >> time_slice;

            for (int i = 0; i < n; i++)
            {
                int pid;
                int at;
                int bt;
                cin >> pid >> at >> bt;
                pcb[j].push_back(new process(pid, at, bt));
                mini = min(mini, at);
            }
        }
    }
    vector<int> visited(6, 0);
    srand(time(0));
    int time = 0;
    int x = 0;
    for (int i = 0; i < 6; i++)
    {

        x = (rand() % 6);
        while (true)
        {
            if (visited[x] == 0)
                break;
            x = rand() % 6;
        }
        // cout << x << endl;
        cout << "--------------------------------------\n";
        if (x == 0)
        {
            cout << "\n FCFS scheduling ... \n";
            fcfs(pcb[x], time);
            cout << endl;
        }
        else if (x == 1)
        {
            cout << "\n SJF scheduling ... \n";
            sjf(pcb[x], time);
            cout << endl;
        }
        else if (x == 2)
        {
            cout << "\n SRTF scheduling ... \n";
            srtf(pcb[x], time);
            cout << endl;
        }
        else if (x == 3)
        {
            cout << "\n Priority scheduling ... \n";
            priority(pcb[x], time);
            cout << endl;
        }
        else if (x == 4)
        {
            cout << "\n Preemptive Priority scheduling ... \n";
            PreemptivePriority(pcb[x], time);
            cout << endl;
        }
        else if (x == 5)
        {

            cout << "\n Round Robin scheduling ... \n";
            RoundRobin(pcb[x], time, time_slice);
            cout << endl;
        }
        visited[x] = 1;
        cout << "--------------------------------------\n";
    }

    // for (int it : visited)
    // {
    //     cout << endl
    //          << it;
    // }

    return 0;
}
