#include <bits/stdc++.h>
#include <unistd.h>
#include <semaphore.h>

using namespace std;
pthread_t *producers;
pthread_t *consumers;

class monitor
{
public:
    sem_t binary_s, empty_count, fill_count;
    int in, out, prod_count, con_count, buf_len;
    vector<int> buf;

    monitor(int v1, int v2, int v3)
    {
        prod_count = v1;
        con_count = v2;
        buf_len = v3;

        in = 0;
        out = 0;

        sem_init(&binary_s, 0, 1);
        sem_init(&fill_count, 0, 0);
        sem_init(&empty_count, 0, buf_len);
        buf = vector<int>(buf_len, 0);
    }

    void show_buffer()
    {
        printf("Buffer:");
        for (int j = 0; j < buf_len; ++j)
            cout << buf[j] << "  ";
        cout << endl;
    }

    void producer_util()
    {

        while (1)
        {
            int p_item = produce(pthread_self());
            sem_wait(&empty_count);
            sem_wait(&binary_s);
            buf[in] = p_item;
            in = (in + 1) % buf_len; // critical section
            show_buffer();
            sem_post(&binary_s);
            sem_post(&fill_count);
            sleep(1 + rand() % 5);
        }
    }

    void consumer_util()
    {
        int c;
        while (1)
        {
            sem_wait(&fill_count);
            sem_wait(&binary_s);
            c = buf[out];
            consume(c, pthread_self());
            out = (out + 1) % buf_len;
            sem_post(&binary_s);
            sem_post(&empty_count);
            sleep(1 + rand() % 5);
        }
    }

    int produce(pthread_t self)
    {
        int i = 0;
        int p_item = 1 + rand() % 50;
        while (!pthread_equal(*(producers + i), self) && i < prod_count)
        {
            i++;
        }
        printf("Producer %d produced %d \n", i + 1, p_item);
        return p_item;
    }

    void consume(int p, pthread_t self)
    {
        int i = 0;
        while (!pthread_equal(*(consumers + i), self) && i < con_count)
        {
            i++;
        }

        printf("\nConsumer %d consumed %d\n", i + 1, p);
        buf[out] = 0;
        show_buffer();
    }
};

monitor *M;

void *producer(void *args)
{
    M->producer_util();
    return NULL;
}

void *consumer(void *args)
{
    M->consumer_util();
    return NULL;
}

int main(void)
{

    int i, err;

    srand(time(NULL));

    int prod_count, con_count, buf_len;

    cout << "Enter the number of Producers:";
    cin >> prod_count;
    producers = new pthread_t[prod_count];

    cout << "Enter the number of Consumers:";
    cin >> con_count;
    consumers = new pthread_t[con_count];

    printf("Enter buffer capacity:");
    cin >> buf_len;

    M = new monitor(prod_count, con_count, buf_len);

    for (i = 0; i < prod_count; i++)
    {
        err = pthread_create(producers + i, NULL, &producer, NULL);
        if (err != 0)
        {
            printf("Error creating producer %d: %s\n", i + 1, strerror(err));
        }
        else
        {
            printf("Successfully created producer %d\n", i + 1);
        }
    }

    for (i = 0; i < con_count; i++)
    {
        err = pthread_create(consumers + i, NULL, &consumer, NULL);
        if (err != 0)
        {
            printf("Error creating consumer %d: %s\n", i + 1, strerror(err));
        }
        else
        {
            printf("Successfully created consumer %d\n", i + 1);
        }
    }

    for (i = 0; i < prod_count; i++)
    {
        pthread_join(*(producers + i), NULL);
    }
    for (i = 0; i < con_count; i++)
    {
        pthread_join(*(consumers + i), NULL);
    }

    return 0;
}