#include<bits/stdc++.h>
#include <unistd.h>
#include <semaphore.h>


using namespace std;

pthread_t *readers;
pthread_t *writers;

sem_t mutex_s,db_s;

int current_readers=0,current_writer=0,writers_count=0,readers_count=0,rc=0;


void read_db(pthread_t self){
    int i=0;
    while(!pthread_equal(*(readers+i),self) && i < readers_count){
            i++;
        }
    rc++;
    printf("\nReader %d is reading from Database \n",i+1);
    printf("Reader = %d   and  Writer = %d \n\n", rc,current_writer);
    rc--;
    
}

void write_db(pthread_t self){
    int i=0;
    while(!pthread_equal(*(writers+i),self) && i < writers_count){
            i++;
        }
    current_writer++;
    printf("\nWriter %d is writing in Database \n",i+1);
    printf("Reader = %d   and  Writer = %d \n\n", rc,current_writer);
    current_writer--;
}


void* writing(void *args){

	while(1){
		// int p_item = produce(pthread_self());
		sem_wait(&db_s);
        
			// critical section
        write_db(pthread_self());
        
		sem_post(&db_s);
		// sem_post(&fill_count);
		sleep(1 + rand()%5);
	}
	
	return NULL;
}


void* reading(void *args){
	int c;
	while(1){
		sem_wait(&mutex_s);
        current_readers++;
        if(current_readers==1)
            sem_wait(&db_s);
        
		sem_post(&mutex_s);
        read_db(pthread_self());
		// c = buf[out];
        sem_wait(&mutex_s);
        current_readers--;

        if(current_readers==0)
            sem_post(&db_s);
        
        sem_post(&mutex_s);

		
		sleep(1+rand()%5);
	}

	return NULL;
}

int main(void){
	
	

	srand(time(NULL));

	sem_init(&mutex_s,0,1);
	sem_init(&db_s,0,1);

	cout<<"Enter the number of writers:";
	cin>>writers_count;
	writers = new pthread_t[writers_count];


	cout<<"Enter the number of readers:";
	cin>>readers_count;
	readers = new pthread_t[readers_count];


	

    int i=0,j=0,err;

    while(i<writers_count || j<readers_count){
        bool chance = rand()%2==0;

        if(chance==true && i<writers_count){
            err = pthread_create(writers+i,NULL,&writing,NULL);
            if(err != 0){
                printf("Error creating writer %d: %s\n",i+1,strerror(err));
            }else{
                printf("Successfully created writer %d\n",i+1);
            }
            i++;
        }
        else if(chance == false && j<readers_count){
            err = pthread_create(readers+j,NULL,&reading,NULL);
            if(err != 0){
                printf("Error creating reader %d: %s\n",j+1,strerror(err));
            }else{
                printf("Successfully created reader %d\n",j+1);
            }
            j++;
        }
    }

	for(i=0;i<readers_count;i++){
		pthread_join(*(readers+i),NULL);
	}
	for(i=0;i<writers_count;i++){
		pthread_join(*(writers+i),NULL);
	}
	return 0;
}