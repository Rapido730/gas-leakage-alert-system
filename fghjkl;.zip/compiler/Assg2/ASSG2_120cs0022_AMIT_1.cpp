// Input and output template
// no. of production rules = 2
// Enter grammer :
// S cAd
// A ab|a
// Enter string = cad
// output = The string is accepted

#include <bits/stdc++.h>
using namespace std;

unordered_map<char, vector<string>> gram;
vector<string> expSplitter(string exp)
{
    int ind = 0;
    string s = "";
    vector<string> ans;

    while (ind <= exp.size())
    {
        if (ind == exp.size() || exp[ind] == '|')
        {
            ans.push_back(s);
            s = "";
        }
        else
        {
            s.push_back(exp[ind]);
        }
        ind++;
    }

    return ans;
}

bool leftHandDerivation(string s, string cur_string)
{
    if (cur_string.length() > s.length())
    {
        return false;
    }

    if (cur_string.length() == s.length() && cur_string == s)
    {
        return true;
    }

    for (int i = 0; i < cur_string.length(); i++)
    {
        if (cur_string[i] >= 'A' && cur_string[i] <= 'Z')
        {
            for (string derv : gram[cur_string[i]])
            {
                string temp = cur_string.substr(0, i) + derv + cur_string.substr(i + 1);
                if (leftHandDerivation(s, temp))
                {
                    return true;
                }
            }
        }
    }
    return false;
}

int main()
{
    int n;
    cout << "no. of production rules = ";
    cin >> n;

    unordered_map<char, int> variables;
    unordered_map<char, int> terminals;
    int t = 0;
    int v = 0;
    terminals['$'] = t++;
    char S = 'S';
    cout << "Enter grammer : \n";
    for (int i = 0; i < n; i++)
    {
        char V;
        cin >> V;
        if (i == 0)
        {
            S = V;
        }
        variables[V] = v++;
        ;
        string exp;
        cin >> exp;

        vector<string> ans;
        ans = expSplitter(exp);

        gram[V] = ans;
    }
    string s;
    cout << "Enter string = ";
    cin >> s;
    string cur_string;
    cur_string.push_back(S);

    cout << "output = ";
    if (leftHandDerivation(s, cur_string))
    {
        cout << "The string is accepted";
    }
    else
    {
        cout << "The string is rejected";
    }

    return 0;
}
