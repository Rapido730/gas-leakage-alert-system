#include <bits/stdc++.h>
using namespace std;


int main (){
    string s = "nkjcnskjcdsmnc";

    string temp  = s.substr(0,0) + "|||"+s.substr(1);
    cout<<temp;
    return 0;
}