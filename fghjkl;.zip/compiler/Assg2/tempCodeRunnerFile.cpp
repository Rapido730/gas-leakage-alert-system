5
// E TA

// A +TA|^

// T FB

// B *FB|^

// F (E)|i